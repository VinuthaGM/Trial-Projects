package com.fintellix.ddengine.metadataengine.model;


public class DDLookupMaster {
	
	private DDLookupMasterPk ddLookupMasterPk;
	private String columnType;
	private String businessName;
	private String referenceObjectName;
	private String srcObjectName;
	private String tgtObjectName;
	private String bkeyColumnName;
	private String pkeyColumnName;
	private String dataSourceInd;
	private String isActive;
	private String hierarchicalIndicator;
	
	public static class DDLookupMasterPk {
		
		private String columnName;
		private String objectName;
		private Integer xrefId;

		public String getColumnName() {
			return columnName;
		}

		public void setColumnName(String columnName) {
			this.columnName = columnName;
		}

		public String getObjectName() {
			return objectName;
		}

		public void setObjectName(String objectName) {
			this.objectName = objectName;
		}

		public Integer getXrefId() {
			return xrefId;
		}

		public void setXrefId(Integer xrefId) {
			this.xrefId = xrefId;
		}
	
	}

	public DDLookupMasterPk getDdLookupMasterPk() {
		return ddLookupMasterPk;
	}

	public void setDdLookupMasterPk(DDLookupMasterPk ddLookupMasterPk) {
		this.ddLookupMasterPk = ddLookupMasterPk;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getReferenceObjectName() {
		return referenceObjectName;
	}

	public void setReferenceObjectName(String referenceObjectName) {
		this.referenceObjectName = referenceObjectName;
	}

	public String getSrcObjectName() {
		return srcObjectName;
	}

	public void setSrcObjectName(String srcObjectName) {
		this.srcObjectName = srcObjectName;
	}

	public String getTgtObjectName() {
		return tgtObjectName;
	}

	public void setTgtObjectName(String tgtObjectName) {
		this.tgtObjectName = tgtObjectName;
	}

	public String getBkeyColumnName() {
		return bkeyColumnName;
	}

	public void setBkeyColumnName(String bkeyColumnName) {
		this.bkeyColumnName = bkeyColumnName;
	}

	public String getPkeyColumnName() {
		return pkeyColumnName;
	}

	public void setPkeyColumnName(String pkeyColumnName) {
		this.pkeyColumnName = pkeyColumnName;
	}

	public String getDataSourceInd() {
		return dataSourceInd;
	}

	public void setDataSourceInd(String dataSourceInd) {
		this.dataSourceInd = dataSourceInd;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getHierarchicalIndicator() {
		return hierarchicalIndicator;
	}

	public void setHierarchicalIndicator(String hierarchicalIndicator) {
		this.hierarchicalIndicator = hierarchicalIndicator;
	}
	
}
