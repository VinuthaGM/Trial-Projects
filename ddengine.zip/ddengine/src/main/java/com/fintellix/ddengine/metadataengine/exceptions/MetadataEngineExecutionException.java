package com.fintellix.ddengine.metadataengine.exceptions;

public class MetadataEngineExecutionException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MetadataEngineExecutionException() {
		
	}
	
	public MetadataEngineExecutionException(String message) {
		super(message);
	}
	
	public MetadataEngineExecutionException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MetadataEngineExecutionException(String message, Throwable cause) {
		super(message, cause);
	}

}