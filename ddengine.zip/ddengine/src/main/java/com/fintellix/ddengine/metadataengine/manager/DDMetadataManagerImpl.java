package com.fintellix.ddengine.metadataengine.manager;

import static ch.lambdaj.Lambda.collect;
import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;
import static ch.lambdaj.Lambda.selectDistinct;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.hamcrest.core.IsEqual;
import org.hamcrest.text.IsEqualIgnoringCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.ddconditionclasses.ConditionXML;
import com.fintellix.ddengine.common.ddconditionclasses.DDSubConditionConfig;
import com.fintellix.ddengine.common.ddconditionclasses.NormalDimConfig;
import com.fintellix.ddengine.metadataengine.dao.MetadataEngineDao;
import com.fintellix.ddengine.metadataengine.dao.MetadataEngineSqlConnectionDao;
import com.fintellix.ddengine.metadataengine.exceptions.MetadataEngineExecutionException;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster.DDConditionMetadata;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster.DDMainCondition;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster.DDMetadata;
import com.fintellix.ddengine.metadataengine.helperobject.NormalDimensionLookUpKey;
import com.fintellix.ddengine.metadataengine.helperobject.NormalDimensionObject;
import com.fintellix.ddengine.metadataengine.model.DDLookupMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;
import com.fintellix.ddengine.metadataengine.model.DDPreprocessRulesMetadata;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

public class DDMetadataManagerImpl implements DDMetadataManager{

	private static Logger logger = LoggerFactory.getLogger(DDMetadataManagerImpl.class); 
	private static Set<NormalDimensionObject> listOfChildNodes = new HashSet<>();
	private static NormalDimensionObject subParentNode = null;
	private static List<NormalDimensionObject> listOfLeafNodes = new ArrayList<>();

	@Override
	public DDMetadataMaster getDDMetadataForSourceTarget(String sourceName,
			String targetName, Connection connectionMart,
			Connection connectionApp, Integer periodId, Integer solutionId) {
		logger.info("DDMetadataManagerImpl-->getDDMetadataForSourceTarget()");
		DDMetadataMaster ddMetadataMaster=null;
		try{
			MetadataEngineDao dataAccessObject = new MetadataEngineSqlConnectionDao(connectionMart, connectionApp, sourceName, targetName, periodId, solutionId);
			ddMetadataMaster = this.executeDDMetadataEngine(dataAccessObject, periodId);
		}
		catch(Exception e){
			e.printStackTrace();
			throw new MetadataEngineExecutionException(e.getMessage(),e); 
		}
		return ddMetadataMaster;
	}

	private DDMetadataMaster executeDDMetadataEngine(MetadataEngineDao dataAccessObject,Integer periodId){
		logger.info("DDMetadataManagerImpl-->executeDDMetadataEngine()");

		logger.info("DD Metadata fetch from db start time "+new Date().getSeconds());
		//get all data from metadata tables
		List<DDPreprocessRulesMetadata> ddPreprocessMetadataResultList=dataAccessObject.getDDPreprocessRulesMetadata();
		if(ddPreprocessMetadataResultList.size()==0){
			logger.info("No data present in DD_PREPROCESS_RULES_METADATA");
			return new DDMetadataMaster();
		}
		List<DDLookupMaster> lookupMasterResultList=dataAccessObject.getDDLookupMaster();

		List<DDMetadataObjectColumn> metadataObjectColumnList=dataAccessObject.getDDMetadataObjectColumn();
		if(metadataObjectColumnList.size()==0)
			throw new MetadataEngineExecutionException("No data present in DD_METADATA_OBJECT_COLUMN");

		List<Integer> holidayPeriodIdList=dataAccessObject.getHolidaysListFromDimPeriod();

		if(null==ddPreprocessMetadataResultList || null==ddPreprocessMetadataResultList || null==metadataObjectColumnList || null==holidayPeriodIdList)
			throw new MetadataEngineExecutionException("Error while fetching metadata kindly check logs");
		logger.info("DD Metadata fetch from db end time----------->"+new Date().getSeconds());
		//build cache loader for normal dimensions lookup
		LoadingCache<NormalDimensionLookUpKey, List<NormalDimensionObject>> normalDimensionLookUpObjectCache=null;
		try{
			normalDimensionLookUpObjectCache = 
					CacheBuilder.newBuilder().maximumSize(10000).expireAfterAccess(30, TimeUnit.MINUTES).build(
							new CacheLoader<NormalDimensionLookUpKey, List<NormalDimensionObject>>() {  
								@Override
								public List<NormalDimensionObject> load(NormalDimensionLookUpKey dimensionName){
									return getNormalDimensionLookUpObject(dimensionName,dataAccessObject);
								} 
							});
		}
		catch(Exception e){
			throw new MetadataEngineExecutionException("Unable to build guava cache");
		}


		logger.info("DD Metadata engine start time----------->"+new Date().getSeconds());
		DDMetadataMaster ddMetadataMaster = new DDMetadataMaster();
		try{
			List<DDLookupMaster> lookupMasterDDimWise=null;
			List<DDPreprocessRulesMetadata> listOfDataForEachDerivedDimension = null;
			List<DDPreprocessRulesMetadata> listOfDataForEachDDIMValue=null;

			NormalDimensionLookUpKey lookupKey = new NormalDimensionLookUpKey();
			Map<String,List<NormalDimensionObject>> dimBusinessNameLookUpObject = new HashMap<String, List<NormalDimensionObject>>();
			Map<String,String> dimBusinessNameDataSourceInd = new HashMap<String,String>();

			Collection<Integer> distinctDdimValueId =null;
			DDMetadata eachDDimMetadata = new DDMetadata();
			List<DDMetadata> ddMetadata= new ArrayList<DDMetadata>();
			DDConditionMetadata eachDDimConditionMetadata =new DDConditionMetadata();
			List<DDConditionMetadata> ddConditionMetadata= new ArrayList<DDConditionMetadata>();
			List<DDSubConditionConfig> listOfSubConditons=new ArrayList<DDSubConditionConfig>();
			DDMainCondition ddValueWiseMainCondition = new DDMainCondition();
			List<DDMainCondition> listOfMainConditionDDValueWise= new ArrayList<DDMainCondition>();

			Map<String,List<String>> ddNameAndUnderlyingColumns = new HashMap<String,List<String>>();
			List<String> underlyingColumnsForPriority = new ArrayList<String>();

			InputStream file =null;
			JAXBContext jaxbContext = JAXBContext.newInstance(ConditionXML.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			ConditionXML conditionXml=null;

			Collection<Integer> distinctXrefs =selectDistinct(collect(ddPreprocessMetadataResultList,on(DDPreprocessRulesMetadata.class).getDdPreprocessRulesMetadataPk().getXrefId()));
			//for each xref 
			for(Integer eachDim:distinctXrefs){
				ddConditionMetadata= new ArrayList<DDConditionMetadata>();
				underlyingColumnsForPriority = new ArrayList<String>();
				listOfDataForEachDerivedDimension=select(ddPreprocessMetadataResultList,having(on(DDPreprocessRulesMetadata.class).getDdPreprocessRulesMetadataPk().getXrefId(),IsEqual.equalTo(eachDim)));				

				eachDDimMetadata = new DDMetadata();
				eachDDimMetadata.setBkeyToIdInd(listOfDataForEachDerivedDimension.get(0).getBkeyToIdInd());
				eachDDimMetadata.setDdimName(listOfDataForEachDerivedDimension.get(0).getDdTechName());
				eachDDimMetadata.setDdimTechName(listOfDataForEachDerivedDimension.get(0).getDdTechName());
				eachDDimMetadata.setEvaluationMode(listOfDataForEachDerivedDimension.get(0).getEvaluationMode());
				eachDDimMetadata.setXrefID(eachDim);
				eachDDimMetadata.setPeriodId(periodId);
				eachDDimMetadata.setSrcName(listOfDataForEachDerivedDimension.get(0).getSourceName());
				eachDDimMetadata.setTrgtName(listOfDataForEachDerivedDimension.get(0).getTargetName());

				//create and cache normal dim lookup for NormalDimensionLookUpKey
				if(eachDDimMetadata.getBkeyToIdInd().equalsIgnoreCase("Y")){
					lookupMasterDDimWise=select(lookupMasterResultList,having(on(DDLookupMaster.class).getDdLookupMasterPk().getXrefId(),IsEqual.equalTo(eachDDimMetadata.getXrefID())));
					if(lookupMasterDDimWise.size()==0)
						logger.info("No data present in DD_LOOKUP_MASTER for xrefID "+eachDDimMetadata.getXrefID());
					for(DDLookupMaster eachLookupMaster:lookupMasterDDimWise){
						lookupKey = new NormalDimensionLookUpKey();
						lookupKey.setBkeyColumn(eachLookupMaster.getBkeyColumnName());
						lookupKey.setDataSourceInd(eachLookupMaster.getDataSourceInd());
						lookupKey.setIdColumn(eachLookupMaster.getPkeyColumnName());
						lookupKey.setObjectName(eachLookupMaster.getDdLookupMasterPk().getObjectName());
						lookupKey.setHierarchicalIndicator(eachLookupMaster.getHierarchicalIndicator());
						dimBusinessNameLookUpObject.put(eachLookupMaster.getBusinessName(), normalDimensionLookUpObjectCache.get(lookupKey));
						dimBusinessNameDataSourceInd.put(eachLookupMaster.getBusinessName(), eachLookupMaster.getDataSourceInd());
					}
				}

				distinctDdimValueId=selectDistinct(collect(listOfDataForEachDerivedDimension,on(DDPreprocessRulesMetadata.class).getDdPreprocessRulesMetadataPk().getDdimValueId()));
				//for each distinct ddim value
				for(Integer eachDDimValue:distinctDdimValueId){
					listOfMainConditionDDValueWise= new ArrayList<DDMainCondition>();
					listOfDataForEachDDIMValue=select(listOfDataForEachDerivedDimension,having(on(DDPreprocessRulesMetadata.class).getDdPreprocessRulesMetadataPk().getDdimValueId(),IsEqual.equalTo(eachDDimValue)));					

					eachDDimConditionMetadata =new DDConditionMetadata();
					eachDDimConditionMetadata.setDdimValueBkey(listOfDataForEachDDIMValue.get(0).getDdimValuebkey().trim());
					eachDDimConditionMetadata.setDdimValueID(listOfDataForEachDDIMValue.get(0).getDdPreprocessRulesMetadataPk().getDdimValueId());
					eachDDimConditionMetadata.setPriority(listOfDataForEachDDIMValue.get(0).getDdPreprocessRulesMetadataPk().getPriority());
					eachDDimConditionMetadata.setUserReferenceId(listOfDataForEachDDIMValue.get(0).getUserReferenceId());
					eachDDimConditionMetadata.setDimReferenceId(listOfDataForEachDDIMValue.get(0).getDimReferenceId());
					//for each condition of a ddim value 
					for(DDPreprocessRulesMetadata eachDDimValueWiseCondition:listOfDataForEachDDIMValue){

						listOfSubConditons=new ArrayList<DDSubConditionConfig>();
						//underlyingColumnsForPriority = new ArrayList<String>();

						ddValueWiseMainCondition = new DDMainCondition();
						ddValueWiseMainCondition.setConditionId(eachDDimValueWiseCondition.getDdPreprocessRulesMetadataPk().getConditionId());
						file =  new ByteArrayInputStream(eachDDimValueWiseCondition.getConditionXml().getBytes());
						conditionXml = (ConditionXML) jaxbUnmarshaller.unmarshal(file);
						ddValueWiseMainCondition.setConditionName(conditionXml.getConditionName());
						ddValueWiseMainCondition.setDataSourceID(conditionXml.getDataSourceId().longValue());
						ddValueWiseMainCondition.setDataSourceName(conditionXml.getDataSourceName());						

						if(conditionXml.getCondition().getArithmeticOperations().getArithmeticOperations()!=null){	
							handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(conditionXml.getCondition().getArithmeticOperations().getArithmeticOperations(), underlyingColumnsForPriority, metadataObjectColumnList,eachDDimMetadata.getSrcName());
							listOfSubConditons.addAll(conditionXml.getCondition().getArithmeticOperations().getArithmeticOperations());
						}
						if(conditionXml.getCondition().getDateDimensions().getDateDimensions()!=null){
							handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(conditionXml.getCondition().getDateDimensions().getDateDimensions(), underlyingColumnsForPriority, metadataObjectColumnList,eachDDimMetadata.getSrcName());
							listOfSubConditons.addAll(conditionXml.getCondition().getDateDimensions().getDateDimensions());
						}
						if(conditionXml.getCondition().getDateOperations().getDateOperations()!=null){
							handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(conditionXml.getCondition().getDateOperations().getDateOperations(), underlyingColumnsForPriority, metadataObjectColumnList,eachDDimMetadata.getSrcName());							
							listOfSubConditons.addAll(conditionXml.getCondition().getDateOperations().getDateOperations());
						}
						if(conditionXml.getCondition().getNormalDimensions().getNormalDimensions()!=null){
							if(eachDDimMetadata.getBkeyToIdInd().equalsIgnoreCase("Y")){
								// add hierarchical key to conditionXml
								List<DDLookupMaster> filteredLookupMasterForXrefAndDimensionName=null;
								for(NormalDimConfig eachCondition: conditionXml.getCondition().getNormalDimensions().getNormalDimensions()){
									filteredLookupMasterForXrefAndDimensionName=select(lookupMasterResultList,having(on(DDLookupMaster.class).getDdLookupMasterPk().getXrefId(),IsEqual.equalTo(eachDDimMetadata.getXrefID()))
											.and(having(on(DDLookupMaster.class).getBusinessName(),IsEqualIgnoringCase.equalToIgnoringCase(eachCondition.getDimensionName()))));
									if(filteredLookupMasterForXrefAndDimensionName!=null && filteredLookupMasterForXrefAndDimensionName.size()>0){
										eachCondition.setHierarchicalIndicator(filteredLookupMasterForXrefAndDimensionName.get(0).getHierarchicalIndicator());
									}
									else{
										eachCondition.setHierarchicalIndicator("N");
									}
								}
								handleConversionOfBkeysToIdsForNormalDimConfig(conditionXml, dimBusinessNameLookUpObject, dimBusinessNameDataSourceInd, ddValueWiseMainCondition.getDataSourceID());	
							} else {
								handleConversionOfBkeysToLeafNodeBkeysForNormalDimConfig(conditionXml, dimBusinessNameLookUpObject, dimBusinessNameDataSourceInd, ddValueWiseMainCondition.getDataSourceID());
							}
							handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(conditionXml.getCondition().getNormalDimensions().getNormalDimensions(), underlyingColumnsForPriority, metadataObjectColumnList,eachDDimMetadata.getSrcName());
							listOfSubConditons.addAll(conditionXml.getCondition().getNormalDimensions().getNormalDimensions());
						}
						if(conditionXml.getCondition().getNumericDimensions().getNumericDimensions()!=null){
							handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(conditionXml.getCondition().getNumericDimensions().getNumericDimensions(), underlyingColumnsForPriority, metadataObjectColumnList,eachDDimMetadata.getSrcName());
							listOfSubConditons.addAll(conditionXml.getCondition().getNumericDimensions().getNumericDimensions());
						}
						if(conditionXml.getCondition().getStringDimensions().getStringDimensions()!=null){
							handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(conditionXml.getCondition().getStringDimensions().getStringDimensions(), underlyingColumnsForPriority, metadataObjectColumnList,eachDDimMetadata.getSrcName());
							listOfSubConditons.addAll(conditionXml.getCondition().getStringDimensions().getStringDimensions());
						}
						ddValueWiseMainCondition.setSubConditionList(listOfSubConditons);	
						listOfMainConditionDDValueWise.add(ddValueWiseMainCondition);
					}
					eachDDimConditionMetadata.setMainConditionList(listOfMainConditionDDValueWise);
					ddConditionMetadata.add(eachDDimConditionMetadata);
				}
				ddConditionMetadata.sort((d1, d2) -> d1.getPriority().compareTo(d2.getPriority()));
				eachDDimMetadata.setDdimWiseConditionMetadataList(ddConditionMetadata);
				Iterator<String> itr = underlyingColumnsForPriority.iterator();
				String eachColumnDD="";
				while (itr.hasNext()) {
					eachColumnDD=itr.next();
					if(eachColumnDD.trim().equalsIgnoreCase(eachDDimMetadata.getDdimTechName().trim())){
						itr.remove();
					}
				}

				underlyingColumnsForPriority=underlyingColumnsForPriority.stream().distinct().collect(Collectors.toList());
				ddNameAndUnderlyingColumns.put(eachDDimMetadata.getDdimTechName(), underlyingColumnsForPriority);
				ddMetadata.add(eachDDimMetadata);
			}
			//calculating dd priority
			Map<String,Integer> priorityMap = getPriority(ddNameAndUnderlyingColumns, ddNameAndUnderlyingColumns.keySet().stream().collect(Collectors.toList()), 1, new HashMap<String, Integer>(),new HashMap<String, Integer>());
			for(DDMetadata eachDimMetadata:ddMetadata){
				eachDimMetadata.setMainPriority(priorityMap.get(eachDimMetadata.getDdimTechName()));	
			}
			ddMetadata.sort((d1, d2) -> d1.getMainPriority().compareTo(d2.getMainPriority()));
			ddMetadataMaster.setDdimWiseMetadata(ddMetadata);
			ddMetadataMaster.setApplicableDDimPorts(ddNameAndUnderlyingColumns.keySet().stream().collect(Collectors.toList()));	
			ddMetadataMaster.setHolidayPeriodIdList(holidayPeriodIdList);
		}
		catch(Exception e){
			//e.printStackTrace();
			throw new MetadataEngineExecutionException(e.getMessage(),e);
		}
		logger.info("DD Metadata engine end time----------->"+new Date().getSeconds());
		return ddMetadataMaster;
	}

	private List<NormalDimensionObject> getNormalDimensionLookUpObject(NormalDimensionLookUpKey dimensionKey,MetadataEngineDao dataAccessObject){
		logger.info("DDMetadataManagerImpl-->getNormalDimensionLookUpObject()");
		return dataAccessObject.getNormalDimensionLookUpObject(dimensionKey);
	}

	private Map<String,Integer> getPriority(Map<String,List<String>> derivedDimensionMap,List<String> distinctDerivedDimensionList, int counter,Map<String,Integer> priMap,Map<String,Integer> priorityMap){
		logger.info("DDMetadataManagerImpl-->getPriority()");
		List<String> listOfUsedDDsAsColumn = new ArrayList<String>();
		List<String> tempDDNameList = new ArrayList<String>();

		if(distinctDerivedDimensionList.size()!=0){
			for(int i=0;i<distinctDerivedDimensionList.size();i++){
				String key = distinctDerivedDimensionList.get(i);
				derivedDimensionMap.entrySet().stream().filter(u -> u.getValue().toString().toLowerCase().contains(key.toLowerCase())).forEach((u) -> listOfUsedDDsAsColumn.add(u.getKey()));				
				//derivedDimensionMap.entrySet().stream().filter(u -> u.getValue().contains(key)).forEach((u) -> listOfUsedDDsAsColumn.add(u.getKey()));
				tempDDNameList.add(key);
			}
			for(int i=0;i<tempDDNameList.size();i++){
				if(!listOfUsedDDsAsColumn.contains(tempDDNameList.get(i))){
					String key = tempDDNameList.get(i);
					priMap.put(key, counter);
					derivedDimensionMap = derivedDimensionMap.entrySet().stream().filter(u -> !u.getKey().equalsIgnoreCase(key)).collect(Collectors.toMap(u -> u.getKey(), u -> u.getValue()));					
					distinctDerivedDimensionList.remove(key);
				}
			}
			priorityMap.putAll(priMap);
			return getPriority(derivedDimensionMap, distinctDerivedDimensionList,++counter,priMap,priorityMap);
		}else{
			return priorityMap;
		}
	}

	private void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(List<? extends DDSubConditionConfig> listOfSubCondition,List<String> underlyingColumns,List<DDMetadataObjectColumn> listOfMetadataObjectColumn,String sourceName){
		logger.info("DDMetadataManagerImpl-->handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns()");
		for(DDSubConditionConfig eachCondition:listOfSubCondition){
			eachCondition.handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(underlyingColumns, listOfMetadataObjectColumn, sourceName);
		}
	}

	private void handleConversionOfBkeysToIdsForNormalDimConfig(ConditionXML conditionXml,Map<String,List<NormalDimensionObject>> dimBusinessNameLookUpObject,Map<String,String> dimBusinessNameDataSourceInd,Long dataSourceId){
		logger.info("DDMetadataManagerImpl-->handleConversionOfBkeysToIdsForNormalDimConfig()");
		String commaSeparatedBkeyValues="";
		String commaSeparatedIdValues="";
		String commaSeparatedLeafBkeyValues="";
		List<NormalDimensionObject> eachDimNormalLookupObject=new ArrayList<NormalDimensionObject>();
		List<NormalDimensionObject> eachDimNormalLookupObjectFilteredList= new ArrayList<NormalDimensionObject>();
		List<NormalDimensionObject> hierarchicalListWithDataSource = new ArrayList<NormalDimensionObject>();
		for(NormalDimConfig eachCondition: conditionXml.getCondition().getNormalDimensions().getNormalDimensions()){
			eachDimNormalLookupObject=dimBusinessNameLookUpObject.get(eachCondition.getDimensionName());
			logger.info("eachDimNormalLookupObject : "+eachDimNormalLookupObject.size());
			if(null==eachDimNormalLookupObject)
				throw new MetadataEngineExecutionException("Error fetching data for "+eachCondition.getDimensionName());
			if(eachDimNormalLookupObject.size()==0)
				throw new MetadataEngineExecutionException("Data not present for dimension "+eachCondition.getDimensionName());
			commaSeparatedBkeyValues=eachCondition.getDimensionValueString();
			logger.info("commaSeparatedBkeyValues : "+commaSeparatedBkeyValues);
			eachCondition.setUnChangedColumnValuesList(eachCondition.getDimensionValueString());
			commaSeparatedIdValues="";
			commaSeparatedLeafBkeyValues = "";
			//get all the leaf nodes
			for(String eachBkey:commaSeparatedBkeyValues.split(",")){
				if(eachCondition.getHierarchicalIndicator().equalsIgnoreCase("Y")){
					if(dimBusinessNameDataSourceInd.get(eachCondition.getDimensionName()).equalsIgnoreCase("Y")){
						hierarchicalListWithDataSource = select (eachDimNormalLookupObject,having(on(NormalDimensionObject.class).getDataSourceId(),IsEqual.equalTo(dataSourceId)));
						//call getLeafNode(bkey,hierarchicalListWithDataSource)
						List<NormalDimensionObject> leafNodeList = getLeafNodes(eachBkey, hierarchicalListWithDataSource);
						if(leafNodeList != null && !leafNodeList.isEmpty()) {
							for(NormalDimensionObject eachLeafNode : leafNodeList){
								commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat(eachLeafNode.getBkey()+",");
								commaSeparatedIdValues=commaSeparatedIdValues.concat(eachLeafNode.getId().toString()+",");
							}
						} else {
							commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat("-999,");
							commaSeparatedIdValues=commaSeparatedIdValues.concat("-999,");
						}
					} else {
						//call getLeafNode(bkey,eachDimNormalLookupObject
						List<NormalDimensionObject> leafNodeList = getLeafNodes(eachBkey, eachDimNormalLookupObject);
						if(!leafNodeList.isEmpty()) {
							for(NormalDimensionObject eachLeafNode : leafNodeList){
								commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat(eachLeafNode.getBkey()+",");
								commaSeparatedIdValues=commaSeparatedIdValues.concat(eachLeafNode.getId().toString()+",");
							}
						} else {
							commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat("-999,");
							commaSeparatedIdValues=commaSeparatedIdValues.concat("-999,");
						}
					}
				}
				else if(dimBusinessNameDataSourceInd.get(eachCondition.getDimensionName()).equalsIgnoreCase("Y")){
					eachDimNormalLookupObjectFilteredList=select(eachDimNormalLookupObject,having(on(NormalDimensionObject.class).getBkey(),IsEqual.equalTo(eachBkey)).and(having(on(NormalDimensionObject.class).getDataSourceId(),IsEqual.equalTo(dataSourceId))));
					if(!eachDimNormalLookupObjectFilteredList.isEmpty()) { 
						for(NormalDimensionObject eachLeafNode : eachDimNormalLookupObjectFilteredList){
							commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat(eachLeafNode.getBkey()+",");
							commaSeparatedIdValues=commaSeparatedIdValues.concat(eachDimNormalLookupObjectFilteredList.get(0).getId().toString()+",");
						}
					} else {
						commaSeparatedIdValues=commaSeparatedIdValues.concat("-999,");
						commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat("-999,");
					}
				}
				else{
					eachDimNormalLookupObjectFilteredList=select(eachDimNormalLookupObject,having(on(NormalDimensionObject.class).getBkey(),IsEqual.equalTo(eachBkey)));
					if(!eachDimNormalLookupObjectFilteredList.isEmpty()){
						for(NormalDimensionObject eachLeafNode : eachDimNormalLookupObjectFilteredList){
							commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat(eachLeafNode.getBkey()+",");
							commaSeparatedIdValues=commaSeparatedIdValues.concat(eachLeafNode.getId().toString()+",");
						}
					} else {
						commaSeparatedIdValues=commaSeparatedIdValues.concat("-999,");
						commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat("-999,");
					}
				}
			}
			commaSeparatedIdValues=commaSeparatedIdValues.substring(0, commaSeparatedIdValues.length()-1);
			commaSeparatedLeafBkeyValues=commaSeparatedLeafBkeyValues.substring(0, commaSeparatedLeafBkeyValues.length()-1);
//			eachCondition.setColumnValueIds(commaSeparatedIdValues);
//			eachCondition.setDimensionValueString(commaSeparatedLeafBkeyValues);
			
			List<String> columnValueIdsList = new ArrayList<String>(Arrays.asList(commaSeparatedIdValues.split(",")));
			Set<String> columnValueIds = new LinkedHashSet<String>(columnValueIdsList);  
			eachCondition.setColumnValueIds(columnValueIds.toString().replaceAll("[\\[\\]]", ""));
			
			List<String> dimensionValueList = new ArrayList<String>(Arrays.asList(commaSeparatedLeafBkeyValues.split(",")));
			Set<String> dimensionValueSet = new LinkedHashSet<String>(dimensionValueList); 
			eachCondition.setDimensionValueString(dimensionValueSet.toString().replaceAll("[\\[\\]]", ""));

		}	
	}


	private void handleConversionOfBkeysToLeafNodeBkeysForNormalDimConfig(ConditionXML conditionXml,Map<String,List<NormalDimensionObject>> dimBusinessNameLookUpObject,Map<String,String> dimBusinessNameDataSourceInd,Long dataSourceId){
		logger.info("DDMetadataManagerImpl-->handleConversionOfBkeysToLeafNodeBkeysForNormalDimConfig()");
		String commaSeparatedBkeyValues="";
		String commaSeparatedLeafBkeyValues="";
		List<NormalDimensionObject> eachDimNormalLookupObject=new ArrayList<NormalDimensionObject>();
		List<NormalDimensionObject> hierarchicalListWithDataSource = new ArrayList<NormalDimensionObject>();
		for(NormalDimConfig eachCondition: conditionXml.getCondition().getNormalDimensions().getNormalDimensions()){
			eachDimNormalLookupObject=dimBusinessNameLookUpObject.get(eachCondition.getDimensionName());
			if(null==eachDimNormalLookupObject)
				throw new MetadataEngineExecutionException("Error fetching data for "+eachCondition.getDimensionName());
			if(eachDimNormalLookupObject.size()==0)
				throw new MetadataEngineExecutionException("Data not present for dimension "+eachCondition.getDimensionName());
			commaSeparatedBkeyValues=eachCondition.getDimensionValueString();
			eachCondition.setUnChangedColumnValuesList(eachCondition.getDimensionValueString());
			commaSeparatedLeafBkeyValues = "";
			//get all leaf nodes
			for(String eachBkey:commaSeparatedBkeyValues.split(",")){
				if(eachCondition.getHierarchicalIndicator().equalsIgnoreCase("Y")){
					if(dimBusinessNameDataSourceInd.get(eachCondition.getDimensionName()).equalsIgnoreCase("Y")){
						hierarchicalListWithDataSource = select (eachDimNormalLookupObject,having(on(NormalDimensionObject.class).getDataSourceId(),IsEqual.equalTo(dataSourceId)));
						//call getLeafNode(bkey,hierarchicalListWithDataSource)
						List<NormalDimensionObject> leafNodeList = getLeafNodes(eachBkey, hierarchicalListWithDataSource);
						if(leafNodeList != null && !leafNodeList.isEmpty()) {
							for(NormalDimensionObject eachLeafNode : leafNodeList){
								commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat(eachLeafNode.getBkey()+",");
							}
						} else {
							commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat("-999,");
						}
					} else {
						//call getLeafNode(bkey,eachDimNormalLookupObject
						List<NormalDimensionObject> leafNodeList = getLeafNodes(eachBkey, eachDimNormalLookupObject);
						if(!leafNodeList.isEmpty()) {
							for(NormalDimensionObject eachLeafNode : leafNodeList){
								commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat(eachLeafNode.getBkey()+",");
							}
						} else {
							commaSeparatedLeafBkeyValues = commaSeparatedLeafBkeyValues.concat("-999,");
						}
					}
				}
			}
			commaSeparatedLeafBkeyValues=commaSeparatedLeafBkeyValues.substring(0, commaSeparatedLeafBkeyValues.length()-1);
			if(eachCondition.getHierarchicalIndicator().equalsIgnoreCase("Y")){
				eachCondition.setDimensionValueString(commaSeparatedLeafBkeyValues);
			}
		}	
	}

	private List<NormalDimensionObject> getLeafNodes(String eachBkey, List<NormalDimensionObject> hierarchicalListWithDataSource) {
//		logger.info("DDMetadataManagerImpl-->getLeafNodes()");
		Long id = null;
		NormalDimensionObject noChildNodes = null;
		for (NormalDimensionObject normalDimensionObject : hierarchicalListWithDataSource) {
//			if (eachBkey == normalDimensionObject.getBkey()) {
			if (eachBkey.equals(normalDimensionObject.getBkey())) {
				id = normalDimensionObject.getId();
				noChildNodes = normalDimensionObject;
			}
			if(id != null){
//				if (id == normalDimensionObject.getParentId()) {
				if (id.equals(normalDimensionObject.getParentId())) {
					listOfChildNodes.add(normalDimensionObject);
				}
			}
		}
		if(listOfChildNodes.isEmpty()){
			if(id == null){
				return null;
			} else {
				listOfLeafNodes.add(noChildNodes);
				return listOfLeafNodes;
			}
		}
		if (subParentNode != null) {
			listOfChildNodes.remove(subParentNode);
		}
		listOfLeafNodes = new ArrayList<>(listOfChildNodes);
		listOfLeafNodes.sort(Comparator.comparing(e -> e.getId()));

		
		for (NormalDimensionObject childNode : listOfLeafNodes) {
			for (NormalDimensionObject normalDimensionObject : hierarchicalListWithDataSource) {
				if (childNode.getId() == normalDimensionObject.getParentId()) {
					subParentNode = childNode;
					getLeafNodes(childNode.getBkey(), hierarchicalListWithDataSource);
					break;
				}
			}
		}
		return listOfLeafNodes;
	}

}