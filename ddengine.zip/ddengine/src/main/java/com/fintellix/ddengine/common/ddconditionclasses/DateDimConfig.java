package com.fintellix.ddengine.common.ddconditionclasses;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import org.hamcrest.core.IsEqual;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.common.CommonDDFunctions;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;


public class DateDimConfig extends DDSubConditionConfig{

	private static Logger logger = LoggerFactory.getLogger(DateDimConfig.class);
	
	private String dimensionName;
	private String timeBasisCode;
	private Integer timeOffset;
	private String lowerTimeBasisCode;
	private Integer lowerTimeOffset;
	private String upperTimeBasisCode;
	private Integer upperTimeOffset;
	public String getDimensionName() {
		return dimensionName;
	}
	@XmlElement(name="DimensionName")
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public String getTimeBasisCode() {
		return timeBasisCode;
	}
	@XmlElement(name="TimeBasisCode")
	public void setTimeBasisCode(String timeBasisCode) {
		this.timeBasisCode = timeBasisCode;
	}
	public Integer getTimeOffset() {
		return timeOffset;
	}
	@XmlElement(name="TimeOffset")
	public void setTimeOffset(Integer timeOffset) {
		this.timeOffset = timeOffset;
	}
	public String getLowerTimeBasisCode() {
		return lowerTimeBasisCode;
	}
	@XmlElement(name="LowerTimeBasisCode")
	public void setLowerTimeBasisCode(String lowerTimeBasisCode) {
		this.lowerTimeBasisCode = lowerTimeBasisCode;
	}
	public Integer getLowerTimeOffset() {
		return lowerTimeOffset;
	}
	@XmlElement(name="LowerTimeOffset")
	public void setLowerTimeOffset(Integer lowerTimeOffset) {
		this.lowerTimeOffset = lowerTimeOffset;
	}
	public String getUpperTimeBasisCode() {
		return upperTimeBasisCode;
	}
	@XmlElement(name="UpperTimeBasisCode")
	public void setUpperTimeBasisCode(String upperTimeBasisCode) {
		this.upperTimeBasisCode = upperTimeBasisCode;
	}
	public Integer getUpperTimeOffset() {
		return upperTimeOffset;
	}
	@XmlElement(name="UpperTimeOffset")
	public void setUpperTimeOffset(Integer upperTimeOffset) {
		this.upperTimeOffset = upperTimeOffset;
	}
	@Override
	public Boolean evaluateSubCondition(Integer periodId, String bkeyToIDConvReqd, Map<String, DDRecordDataObject> eachRecordData, List<Integer> holidayPeriodIdList){
		
		//logger.info("EXEFLOW DateDimConfig -> evaluateSubCondition");
		Boolean returnValue = DDConstants.DD_FAILURE;

		DateTime conditionDate = null;
		DateTime lowerConditionDate = null;
		DateTime upperConditionDate = null;
		DateTime recordDate = null;
		
		if(getOperator().equals(DDConstants.DDOPER_IN))	{
			conditionDate = CommonDDFunctions.convertDateToAbsoluteDate(periodId, getTimeBasisCode(), getTimeOffset());
		}
		else if(getOperator().equals(DDConstants.DDOPER_DATERANGE))	{
			lowerConditionDate = CommonDDFunctions.convertDateToAbsoluteDate(periodId, getLowerTimeBasisCode(), getLowerTimeOffset());
			upperConditionDate = CommonDDFunctions.convertDateToAbsoluteDate(periodId, getUpperTimeBasisCode(), getUpperTimeOffset());
		}
		
		switch(getOperator())		{
		case DDConstants.DDOPER_ISNULL:
			if(eachRecordData.get(getDimensionName().toUpperCase()).getIsNull())
				returnValue = DDConstants.DD_SUCCESS;
			break;
		case DDConstants.DDOPER_ISNOTNULL :
			if(!eachRecordData.get(getDimensionName().toUpperCase()).getIsNull())
				returnValue = DDConstants.DD_SUCCESS;
			break;
		case DDConstants.DDOPER_IN:
			if(eachRecordData.get(getDimensionName().toUpperCase()).getIsNull() || conditionDate == null)
				returnValue = DDConstants.DD_FAILURE;
			else
				if((new DateTime(eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue())).isEqual(conditionDate))
					returnValue = DDConstants.DD_SUCCESS;
			break;
		case DDConstants.DDOPER_DATERANGE:
			if(eachRecordData.get(getDimensionName().toUpperCase()).getIsNull() || lowerConditionDate == null || upperConditionDate == null )
				returnValue = DDConstants.DD_FAILURE;
			else	{
				recordDate = new DateTime(eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue());
				
				if(recordDate.isAfter(lowerConditionDate) || recordDate.isEqual(lowerConditionDate)
						|| recordDate.isBefore(upperConditionDate) || recordDate.isEqual(upperConditionDate))
					returnValue = DDConstants.DD_SUCCESS;
			}		
			break;
		case DDConstants.DDOPER_UNSUPPORTEDOPER:
		default:
			returnValue = DDConstants.DD_FAILURE;
		}
		
		return returnValue;
	}
	@Override
	public void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(
			List<String> underlyingColumns,
			List<DDMetadataObjectColumn> listOfMetadataObjectColumn,
			String sourceName) {
		List<DDMetadataObjectColumn> listOfMetadataObjectColumnFiltered = new ArrayList<DDMetadataObjectColumn>();

		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getDimensionName().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setDimensionName(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		underlyingColumns.add(this.getDimensionName());

	}
	public String toString()	{
		String subCondition = "Sub-condition: " + getOperator();
		switch(getOperator())	{
		case DDConstants.DDOPER_DATERANGE:
			subCondition += " Lower [TimeBasis, Offset]: ["+getLowerTimeBasisCode()+", "+getLowerTimeOffset()+"]) and ";
			subCondition += " Upper [TimeBasis, Offset]: ["+getUpperTimeBasisCode()+", "+getUpperTimeOffset()+"])";
			break;
		default:
			subCondition += " [TimeBasis, Offset]: ["+getTimeBasisCode()+", "+getTimeOffset()+"]";
		
		
		}
		return subCondition;
	}
	
     
}
