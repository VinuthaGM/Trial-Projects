package com.fintellix.ddengine.automationtest.connection;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class AutomationConnection {
	private Properties jdbcProps;
	//private static Logger logger = LoggerFactory.getLogger(AutomationConnection.class); 

	public  AutomationConnection(String path){
		System.out.println("AutomationTest->AutomationConnection->Reading JDBC Properties");
		try {
			System.out.println(path);
		InputStream in = new FileInputStream(new File(path));
		jdbcProps = new Properties();
		
			jdbcProps.load(in);
		} catch (IOException e) {
			System.out.println("FILE NOT FOUND IN THE SPECIFIED PATH");
			e.printStackTrace();
		}
	}

	public Connection getAppDbConnection(){
		System.out.println("AutomationTest->AutomationConnection->getAppDbConnection()");
		Connection martDbConnection=null;
		try {
			Class.forName(jdbcProps.get("jdbc.app.datasourceClassName").toString());

			martDbConnection = DriverManager.getConnection(jdbcProps.get("jdbc.app.url").toString(), jdbcProps.get("jdbc.app.username").toString(), jdbcProps.get("jdbc.app.password").toString());
			return martDbConnection;
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return martDbConnection;
	}

	public Connection getMartDbConnection(){
		System.out.println("AutomationTest->AutomationConnection->getMartDbConnection()");
		Connection appDbConnection=null;
		try {
			Class.forName(jdbcProps.get("jdbc.mart.datasourceClassName").toString());

			appDbConnection = DriverManager.getConnection(jdbcProps.get("jdbc.mart.url").toString(), jdbcProps.get("jdbc.mart.username").toString(), jdbcProps.get("jdbc.mart.password").toString());
			return appDbConnection;
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return appDbConnection;
	}

}
