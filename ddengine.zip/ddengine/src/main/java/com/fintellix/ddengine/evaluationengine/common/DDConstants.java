package com.fintellix.ddengine.evaluationengine.common;

public class DDConstants {

	public final static  boolean DD_SUCCESS = true;
	public final static  boolean DD_FAILURE = false;
	
	public final static Integer DD_NULL_DATA = -1;
	
	public final static Integer DIM_DEFAULT_VALUE = -1;
	
	public final static String DDOPERATION_RATIOOF = "RATIO";
	
	public final static String DD_INVALID_CONDITION_BKEY = "-999";
	public final static String DDOPER_IN = "IN";
	public final static String DDOPER_NOTIN = "NOT IN";
	public final static String DDOPER_ISNOTEMPTY = "IS NOT EMPTY";
	public final static String DDOPER_ISEMPTY = "IS EMPTY";
	public final static String DDOPER_LESSTHAN = "<";  
	public final static String DDOPER_GREATERTHAN = ">";
	public final static String DDOPER_LESSTHANOREQUALTO = "<=";
	public final static String DDOPER_GREATERTHANOREQUALTO = ">=";
	public final static String DDOPER_EQUALTO = "=";
	public final static String DDOPER_NOTEQUALTO = "<>";
	public final static String DDOPER_BETWEEN = "BETWEEN";
	public final static String DDOPER_BETWEEN_LOWER_EXCLUSIVE = "BETWEEN LOWER EXCLUSIVE";
	public final static String DDOPER_BETWEEN_UPPER_EXCLUSIVE = "BETWEEN UPPER EXCLUSIVE";
	public final static String DDOPER_ISNULL = "IS NULL";
	public final static String DDOPER_ISNOTNULL = "IS NOT NULL";
	public final static String DDOPER_DATERANGE = "RANGE";
	public final static String DDOPER_CONTAINS = "CONTAINS";
	public final static String DDOPER_DOESNOTCONTAIN = "DOES NOT CONTAIN";
	public final static String DDOPER_BEGINSWITH = "BEGINS WITH";
	public final static String DDOPER_ENDSWITH = "ENDS WITH";
	public final static String DDOPER_EQUALS = "EQUALS";
	public final static String DDOPER_UNSUPPORTEDOPER = "UNSUPPORTED OPERATOR";
	
	public final static String DATEFUNC_STARTOFMONTH = "MONTH START OF";	
	public final static String DATEFUNC_ENDOFMONTH = "MONTH END OF";
	public final static String DATEFUNC_STARTOFQUARTER = "QUARTER START OF";
	public final static String DATEFUNC_ENDOFQUARTER = "QUARTER END OF";
	public final static String DATEFUNC_STARTOFYEAR = "YEAR START OF";
	public final static String DATEFUNC_ENDOFYEAR = "YEAR END OF";
	public final static String DDOPER_UNSUPPORTEDDATEFUNC = "UNSUPPORTED DATE OPERATOR";
	
	public final static String DATEDIFFMETHOD_DAILY = "D";
	public final static String DATEDIFFMETHOD_WEEKLY = "W";
	public final static String DATEDIFFMETHOD_MONTHLY = "M"; 
	public final static String DATEDIFFMETHOD_QUARTERLY = "Q"; 
	public final static String DATEDIFFMETHOD_YEARLY  = "Y";
	public final static String DATEDIFFMETHOD_WORKINGDAYS = "O";
	public final static String DATEDIFFMETHOD_WHOLEMONTHS = "H";
	public final static String DATEDIFFMETHOD_INVALIDBASISCODE = "INVALID DATEDIFF METHOD";
	
}
