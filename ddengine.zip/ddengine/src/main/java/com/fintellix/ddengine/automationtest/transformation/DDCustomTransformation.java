package com.fintellix.ddengine.automationtest.transformation;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.manager.DDEvaluation;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;

public class DDCustomTransformation {
	//private static Logger logger = LoggerFactory.getLogger(DDCustomTransformation.class); 
	private Map<String, DDRecordDataObject> columnNameAndMetadataMap;
	private DDRecordDataObject ddRecordObject;
	private DDEvaluation ddEvaluation;

	public DDCustomTransformation(DDMetadataMaster ddMetadataMaster){
		System.out.println("AutomationTest->DDCustomTransformation->SET DDMetadataMaster ");
		this.ddEvaluation=new DDEvaluation();
		ddEvaluation.setDDMetadataMaster(ddMetadataMaster);
	}

	public DDEvaluation getDDEvaluationObject(){
		return ddEvaluation;
	}
	public Map<String,DDRecordDataObject> handleCustomTransformationForEachRow(ResultSet rs,List<String> dDimPorts){
		System.out.println("AutomationTest->DDCustomTransformation->handleCustomTransformationForEachRow()");
		columnNameAndMetadataMap=new HashMap<String,DDRecordDataObject>();
		try {
			for(int i=1;i<=rs.getMetaData().getColumnCount();i++){
				ddRecordObject=new DDRecordDataObject();
				ddRecordObject.setDataType(rs.getMetaData().getColumnTypeName(i));
				ddRecordObject.setIsNull(rs.getObject(i)==null?true:false);
				ddRecordObject.setRecordFieldValue(rs.getObject(i)==null?new Object():rs.getObject(i));
				columnNameAndMetadataMap.put(rs.getMetaData().getColumnName(i).toUpperCase(), ddRecordObject);
			}
			for(String singleDDimPort:dDimPorts){
				if(!columnNameAndMetadataMap.containsKey(singleDDimPort)){
					ddRecordObject=new DDRecordDataObject();
					ddRecordObject.setIsNull(true);
					columnNameAndMetadataMap.put(singleDDimPort.toUpperCase(),ddRecordObject);     
				}
			}
			return columnNameAndMetadataMap;
		} catch (Exception e) {
			e.printStackTrace();
			return columnNameAndMetadataMap;
		}


	}

}
