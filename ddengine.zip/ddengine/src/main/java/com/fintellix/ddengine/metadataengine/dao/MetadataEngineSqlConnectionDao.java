package com.fintellix.ddengine.metadataengine.dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.metadataengine.helperobject.NormalDimensionLookUpKey;
import com.fintellix.ddengine.metadataengine.helperobject.NormalDimensionObject;
import com.fintellix.ddengine.metadataengine.model.DDLookupMaster;
import com.fintellix.ddengine.metadataengine.model.DDLookupMaster.DDLookupMasterPk;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn.DDMetadataObjectColumnPk;
import com.fintellix.ddengine.metadataengine.model.DDPreprocessRulesMetadata;
import com.fintellix.ddengine.metadataengine.model.DDPreprocessRulesMetadata.DDPreprocessRulesMetadataPk;


public class MetadataEngineSqlConnectionDao implements MetadataEngineDao{

	private static Logger logger = LoggerFactory.getLogger(MetadataEngineSqlConnectionDao.class);

	private Connection connectionMart;
	private Connection connectionApp;
	private String sourceName;
	private String targetName;
	private Integer periodId;
	private Integer solutionId;


	public MetadataEngineSqlConnectionDao(Connection connectionMart,Connection connectionApp,String sourceName,String targetName,Integer periodId,Integer solutionId){
		this.connectionMart=connectionMart;
		this.connectionApp=connectionApp;
		this.sourceName=sourceName;
		this.targetName=targetName;
		this.periodId=periodId;
		this.solutionId=solutionId;
	}

	private static Properties props;

	static {
		try {
			InputStream in = MetadataEngineSqlConnectionDao.class.getResourceAsStream("metadataqueries.properties");
			props = new Properties();
			props.load(in);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	private static String GETDATAFORPROCESSING = props
			.getProperty("metadataqueries.getDataForProcessing");
	private static String GETDATAFORLOOKUP = props
			.getProperty("metadataqueries.getDataForLookup");
	private static String GETMETADATAOBJECTCOLUMN = props
			.getProperty("metadataqueries.getDataForMetadataObjectColumn");
	private static String GETHOLIDAYFILE = props.getProperty("metadataqueries.getHolidayIndicator");

	@Override
	public List<DDPreprocessRulesMetadata> getDDPreprocessRulesMetadata() {
		logger.info("MetadataEngineSqlConnectionDao----->getDDPreprocessRulesMetadata()");
		List<DDPreprocessRulesMetadata> resultList= new ArrayList<DDPreprocessRulesMetadata>();
		DDPreprocessRulesMetadataPk primarkKey = new DDPreprocessRulesMetadataPk();
		DDPreprocessRulesMetadata ddPreprocessMetadata = new DDPreprocessRulesMetadata();

		try{
			PreparedStatement  stm;
			stm = connectionApp.prepareStatement(GETDATAFORPROCESSING);
			stm.setString(1, sourceName.toUpperCase());
			stm.setString(2, targetName.toUpperCase());
			stm.setInt(3, solutionId);
			stm.setInt(4, periodId);
			stm.setInt(5, periodId);

			ResultSet rst;
			rst = stm.executeQuery();

			while (rst.next()) {
				ddPreprocessMetadata = new DDPreprocessRulesMetadata();
				primarkKey = new DDPreprocessRulesMetadataPk();
				primarkKey.setConditionId(returnNullIfDbValueIsNullForInteger(rst,"CONDITION_ID"));
				primarkKey.setDdimValueId(returnNullIfDbValueIsNullForInteger(rst,"DDIM_VALUE_ID"));
				primarkKey.setPriority(returnNullIfDbValueIsNullForInteger(rst,"PRIORITY"));
				primarkKey.setSerialNumber(returnNullIfDbValueIsNullForInteger(rst,"SL_NO"));
				primarkKey.setSolutionId(returnNullIfDbValueIsNullForInteger(rst,"SOLUTION_ID"));
				primarkKey.setXrefId(returnNullIfDbValueIsNullForInteger(rst,"XREF_ID"));
				ddPreprocessMetadata.setDdPreprocessRulesMetadataPk(primarkKey);

				ddPreprocessMetadata.setBkeyToIdInd(rst.getString("BKY_TO_ID_CONV_REQD"));
				ddPreprocessMetadata.setConditionXml(rst.getString("CONDITION_XML"));
				ddPreprocessMetadata.setDdimValuebkey(rst.getString("DDIM_VALUE_BKEY"));
				ddPreprocessMetadata.setDdTechName(rst.getString("DD_TECH_NAME"));
				ddPreprocessMetadata.setDimReferenceId(returnNullIfDbValueIsNullForInteger(rst,"DIM_REFERENCE_ID"));
				ddPreprocessMetadata.setEvaluationMode(rst.getString("EVALUATION_MODE"));
				ddPreprocessMetadata.setInfaInstanceName(rst.getString("INFA_INSTANCE_NAME"));
				ddPreprocessMetadata.setPriorityRecordEndDate(returnNullIfDbValueIsNullForInteger(rst,"PRIORITY_RECORD_END_DATE"));
				ddPreprocessMetadata.setPriorityRecordStartDate(returnNullIfDbValueIsNullForInteger(rst,"PRIORITY_RECORD_START_DATE"));
				ddPreprocessMetadata.setRulesRecordEndDate(returnNullIfDbValueIsNullForInteger(rst,"RULES_RECORD_END_DATE"));
				ddPreprocessMetadata.setRulesRecordStartDate(returnNullIfDbValueIsNullForInteger(rst,"RULES_RECORD_START_DATE"));
				ddPreprocessMetadata.setSourceName(rst.getString("SRC_NAME"));
				ddPreprocessMetadata.setSubjectArea(rst.getString("SUBJECT_AREA"));
				ddPreprocessMetadata.setTargetName(rst.getString("TGT_NAME"));
				ddPreprocessMetadata.setUserReferenceId(returnNullIfDbValueIsNullForInteger(rst,"USER_REFERENCE_ID"));

				resultList.add(ddPreprocessMetadata);
			}	
			rst.close();
			stm.close();
			return resultList;
		}
		catch(Exception e){
			e.printStackTrace();
			logger.info("Error fetching data from DD_PREPROCESS_RULES_METADATA");
			logger.info(e.getMessage());
			//e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<DDLookupMaster> getDDLookupMaster() {
		logger.info("MetadataEngineSqlConnectionDao----->getDDLookupMaster()");

		List<DDLookupMaster> resultList= new ArrayList<DDLookupMaster>();
		DDLookupMasterPk primarkKey = new DDLookupMasterPk();
		DDLookupMaster lookupMaster= new DDLookupMaster();
		try{
			PreparedStatement  stm;
			stm = connectionApp.prepareStatement(GETDATAFORLOOKUP);
			stm.setString(1, sourceName.toUpperCase());
			stm.setString(2, targetName.toUpperCase());

			ResultSet rst;
			rst = stm.executeQuery();

			while (rst.next()) {
				lookupMaster= new DDLookupMaster();
				primarkKey = new DDLookupMasterPk();
				primarkKey.setColumnName(rst.getString("COLUMN_NAME"));
				primarkKey.setObjectName(rst.getString("OBJECT_NAME"));
				primarkKey.setXrefId(returnNullIfDbValueIsNullForInteger(rst,"XREF_ID"));
				lookupMaster.setDdLookupMasterPk(primarkKey);

				lookupMaster.setBkeyColumnName(rst.getString("BKEY_COL_NAME"));
				lookupMaster.setBusinessName(rst.getString("BUSINESS_NAME"));
				lookupMaster.setColumnType(rst.getString("COLUMN_TYPE"));
				lookupMaster.setDataSourceInd(rst.getString("DATA_SOURCE_IND"));
				lookupMaster.setIsActive(rst.getString("IS_ACTIVE"));
				lookupMaster.setPkeyColumnName(rst.getString("PRIMARY_KEY_COL_NAME"));
				lookupMaster.setReferenceObjectName(rst.getString("REFERENCE_OBJECT_NAME"));
				lookupMaster.setSrcObjectName(rst.getString("SRC_OBJECT_NAME"));
				lookupMaster.setTgtObjectName(rst.getString("TGT_OBJECT_NAME"));
				lookupMaster.setHierarchicalIndicator(rst.getString("HIERARCHICAL_IND"));

				resultList.add(lookupMaster);
			}	
			rst.close();
			stm.close();
			return resultList;
		}
		catch(Exception e){
			logger.info("Error fetching data from DD_LOOKUP_MASTER");
			logger.info(e.getMessage());
			//e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<DDMetadataObjectColumn> getDDMetadataObjectColumn() {
		logger.info("MetadataEngineSqlConnectionDao----->getDDMetadataObjectColumn()");
		List<DDMetadataObjectColumn> resultList= new ArrayList<DDMetadataObjectColumn>();

		DDMetadataObjectColumnPk primarkKey = new DDMetadataObjectColumnPk();
		DDMetadataObjectColumn metadataObjectColumn= new DDMetadataObjectColumn();
		try{
			Statement  stm;
			stm = connectionApp.createStatement();
			ResultSet rst;
			rst = stm.executeQuery(GETMETADATAOBJECTCOLUMN);

			while (rst.next()) {
				metadataObjectColumn= new DDMetadataObjectColumn();
				primarkKey = new DDMetadataObjectColumnPk();
				primarkKey.setColumnName(rst.getString("COLUMN_NAME"));
				primarkKey.setObjectName(rst.getString("OBJECT_NAME"));
				primarkKey.setSolutionId(returnNullIfDbValueIsNullForInteger(rst,"SOLUTION_ID"));
				metadataObjectColumn.setDdMetadataObjectColumnPk(primarkKey);

				metadataObjectColumn.setBusinessName(rst.getString("BUSINESS_NAME"));
				metadataObjectColumn.setBusinessNameAltLang(rst.getString("BUSINESS_NAME_ALT_LANG"));
				metadataObjectColumn.setColumnDataLength(returnNullIfDbValueIsNullForInteger(rst,"COLUMN_DATA_LENGTH"));
				metadataObjectColumn.setColumnDataPrecision(returnNullIfDbValueIsNullForInteger(rst,"COLUMN_DATA_PRECISION"));
				metadataObjectColumn.setColumnDataScale(returnNullIfDbValueIsNullForInteger(rst,"COLUMN_DATA_SCALE"));
				metadataObjectColumn.setColumnDataType(rst.getString("COLUMN_DATA_TYPE"));
				metadataObjectColumn.setColumnNullable(rst.getString("COLUMN_NULLABLE"));
				metadataObjectColumn.setColumnPosition(returnNullIfDbValueIsNullForInteger(rst,"COLUMN_POSITION"));
				metadataObjectColumn.setColumnType(rst.getString("COLUMN_TYPE"));
				metadataObjectColumn.setIsActive(rst.getString("IS_ACTIVE"));
				metadataObjectColumn.setIsReferential(rst.getString("IS_REFERENTIAL"));
				metadataObjectColumn.setReferenceObjectName(rst.getString("REFERENCE_OBJECT_NAME"));

				resultList.add(metadataObjectColumn);
			}
			rst.close();
			stm.close();
			return resultList;
		}
		catch(Exception e){
			logger.info("Error fetching data from DD_METADATA_OBJECT_COLUMN");
			logger.info(e.getMessage());
			//e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<Integer> getHolidaysListFromDimPeriod() {
		logger.info("MetadataEngineSqlConnectionDao----->getHolidaysListFromDimPeriod()");
		List<Integer> resultList= new ArrayList<Integer>();
		try{
			Statement  stm;
			stm = connectionApp.createStatement();
			ResultSet rst;
			rst = stm.executeQuery(GETHOLIDAYFILE);
			while (rst.next()) {
				resultList.add(rst.getInt("PERIOD_ID"));
			}
			rst.close();
			stm.close();
			return resultList;
		}
		catch(Exception e){
			logger.info("Error fetching data from DIM_PERIOD");
			logger.info(e.getMessage());
			//e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<NormalDimensionObject> getNormalDimensionLookUpObject(
			NormalDimensionLookUpKey dimensionKey) {
		logger.info("MetadataEngineSqlConnectionDao----->getNormalDimensionLookUpObject()");

		List<NormalDimensionObject> returnObject = new ArrayList<NormalDimensionObject>();
		NormalDimensionObject eachObject = new NormalDimensionObject();
		StringBuffer query= new StringBuffer();
		try 
		{
			//check for hierarchicalIndicator key if 'Y' then select even parent id 
			query.append("SELECT "+dimensionKey.getIdColumn()+" as ID,"+dimensionKey.getBkeyColumn()+" as BKEY");
			if(dimensionKey.getDataSourceInd().equalsIgnoreCase("Y"))query.append(",DATA_SOURCE_ID");
			if(dimensionKey.getHierarchicalIndicator().equalsIgnoreCase("Y"))query.append(",PARENT_"+dimensionKey.getIdColumn());
			query.append(" from "+dimensionKey.getObjectName());

			Statement  stm;
			stm = connectionMart.createStatement();
			ResultSet rst;
			rst = stm.executeQuery(query.toString());

			while (rst.next()) {
				eachObject = new NormalDimensionObject();
				eachObject.setId(rst.getLong(1));
				eachObject.setBkey(rst.getString(2).trim());
				if(dimensionKey.getDataSourceInd().equalsIgnoreCase("Y"))eachObject.setDataSourceId(rst.getLong(3));
				if(dimensionKey.getHierarchicalIndicator().equalsIgnoreCase("Y"))eachObject.setParentId(rst.getLong("PARENT_"+dimensionKey.getIdColumn()));
				returnObject.add(eachObject);
			}
			rst.close();
			stm.close();
			return returnObject;
		}
		catch(Exception e)
		{
			logger.info("Query executed-----> "+query);
			logger.info(e.getMessage());
			//e.printStackTrace();
			return null;
		}
	}

	private Integer returnNullIfDbValueIsNullForInteger(ResultSet resultColumn,String columnName) throws SQLException{

		Integer value=null;
		value=resultColumn.getInt(columnName);
		if(resultColumn.wasNull()){
			return null;
		}	
		else{
			return value;
		}
	}
}
