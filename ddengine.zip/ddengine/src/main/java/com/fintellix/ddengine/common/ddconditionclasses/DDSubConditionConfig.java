package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;

public abstract class DDSubConditionConfig {
	
	private String operator;
		
	public String getOperator() {
		return operator;
	}
	@XmlElement(name="Operator")
	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public abstract Boolean evaluateSubCondition(Integer periodId, String bkeyToIDConvReqd, Map<String, DDRecordDataObject> eachRecordData, List<Integer> holidayPeriodIdList);
	public abstract void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(List<String> underlyingColumns,List<DDMetadataObjectColumn> listOfMetadataObjectColumn,String sourceName);
}
