package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="StringDimensions")
public class StringDimensions {

	private List<StringDimConfig> stringDimensions;
	
	public List<StringDimConfig> getStringDimensions() {
		return stringDimensions;
	}
	@XmlElement(name="StringDimConfig")
	public void setStringDimensions(List<StringDimConfig> stringDimensions) {
		this.stringDimensions = stringDimensions;
	}
}
