package com.fintellix.ddengine.metadataengine.helperobject;

import java.util.List;

import com.fintellix.ddengine.common.ddconditionclasses.DDSubConditionConfig;

public class DDMetadataMaster {

	//private Map<String,String> underlyingColumnsDatatypeMap;
	private List<String> applicableDDimPorts;
	private List<DDMetadata> ddimWiseMetadata;
	private List<Integer> holidayPeriodIdList;
	
	public static class DDMetadata{
		private Integer periodId;
		private String evaluationMode;
		private String bkeyToIdInd;
		private Integer mainPriority;
		private String ddimName;
		private String ddimTechName;
		private Integer xrefID;
		private String srcName;
		private String trgtName;
		
		private List<DDConditionMetadata> ddimWiseConditionMetadataList;

		public Integer getPeriodId() {
			return periodId;
		}
		public void setPeriodId(Integer periodId) {
			this.periodId = periodId;
		}
		public String getEvaluationMode() {
			return evaluationMode;
		}
		public void setEvaluationMode(String evaluationMode) {
			this.evaluationMode = evaluationMode;
		}
		public String getBkeyToIdInd() {
			return bkeyToIdInd;
		}
		public void setBkeyToIdInd(String bkeyToIdInd) {
			this.bkeyToIdInd = bkeyToIdInd;
		}
		public Integer getMainPriority() {
			return mainPriority;
		}
		public void setMainPriority(Integer mainPriority) {
			this.mainPriority = mainPriority;
		}
		public String getDdimName() {
			return ddimName;
		}
		public void setDdimName(String ddimName) {
			this.ddimName = ddimName;
		}
		public String getDdimTechName() {
			return ddimTechName;
		}
		public void setDdimTechName(String ddimTechName) {
			this.ddimTechName = ddimTechName;
		}
		public Integer getXrefID() {
			return xrefID;
		}
		public void setXrefID(Integer xrefID) {
			this.xrefID = xrefID;
		}
		public List<DDConditionMetadata> getDdimWiseConditionMetadataList() {
			return ddimWiseConditionMetadataList;
		}
		public void setDdimWiseConditionMetadataList(
				List<DDConditionMetadata> ddimWiseConditionMetadataList) {
			this.ddimWiseConditionMetadataList = ddimWiseConditionMetadataList;
		}
		public String getSrcName() {
			return srcName;
		}
		public void setSrcName(String srcName) {
			this.srcName = srcName;
		}
		public String getTrgtName() {
			return trgtName;
		}
		public void setTrgtName(String trgtName) {
			this.trgtName = trgtName;
		}
	}

	public static class DDConditionMetadata{
		private Integer ddimValueID;
		private String ddimValueBkey;
		private Integer priority;
		private Integer dimReferenceId;
		private Integer userReferenceId;
		private List<DDMainCondition> mainConditionList;

		public Integer getDdimValueID() {
			return ddimValueID;
		}
		public void setDdimValueID(Integer ddimValueID) {
			this.ddimValueID = ddimValueID;
		}
		public String getDdimValueBkey() {
			return ddimValueBkey;
		}
		public void setDdimValueBkey(String ddimValueBkey) {
			this.ddimValueBkey = ddimValueBkey;
		}
		public Integer getPriority() {
			return priority;
		}
		public void setPriority(Integer priority) {
			this.priority = priority;
		}
		public List<DDMainCondition> getMainConditionList() {
			return mainConditionList;
		}
		public void setMainConditionList(List<DDMainCondition> mainConditionList) {
			this.mainConditionList = mainConditionList;
		}
		public Integer getDimReferenceId() {
			return dimReferenceId;
		}
		public void setDimReferenceId(Integer dimReferenceId) {
			this.dimReferenceId = dimReferenceId;
		}
		public Integer getUserReferenceId() {
			return userReferenceId;
		}
		public void setUserReferenceId(Integer userReferenceId) {
			this.userReferenceId = userReferenceId;
		}

	}


	public static class DDMainCondition{

		private Integer conditionId;
		private String conditionName;
		private Long dataSourceID;
		private String dataSourceName;
		
		private List<DDSubConditionConfig> subConditionList;

		public Integer getConditionId() {
			return conditionId;
		}
		public void setConditionId(Integer conditionId) {
			this.conditionId = conditionId;
		}
		public String getConditionName() {
			return conditionName;
		}
		public void setConditionName(String conditionName) {
			this.conditionName = conditionName;
		}
		public List<DDSubConditionConfig> getSubConditionList() {
			return subConditionList;
		}
		public void setSubConditionList(List<DDSubConditionConfig> subConditionList) {
			this.subConditionList = subConditionList;
		}
		public Long getDataSourceID() {
			return dataSourceID;
		}
		public void setDataSourceID(Long dataSourceID) {
			this.dataSourceID = dataSourceID;
		}
		public String getDataSourceName() {
			return dataSourceName;
		}
		public void setDataSourceName(String dataSourceName) {
			this.dataSourceName = dataSourceName;
		}

	}


	public List<String> getApplicableDDimPorts() {
		return applicableDDimPorts;
	}


	public void setApplicableDDimPorts(List<String> applicableDDimPorts) {
		this.applicableDDimPorts = applicableDDimPorts;
	}


	public List<DDMetadata> getDdimWiseMetadata() {
		return ddimWiseMetadata;
	}


	public void setDdimWiseMetadata(List<DDMetadata> ddimWiseMetadata) {
		this.ddimWiseMetadata = ddimWiseMetadata;
	}


	public List<Integer> getHolidayPeriodIdList() {
		return holidayPeriodIdList;
	}


	public void setHolidayPeriodIdList(List<Integer> holidayPeriodIdList) {
		this.holidayPeriodIdList = holidayPeriodIdList;
	}


}
