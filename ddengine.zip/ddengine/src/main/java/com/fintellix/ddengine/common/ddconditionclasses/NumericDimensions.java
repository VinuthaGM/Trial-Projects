package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="NumericDimensions")
public class NumericDimensions {

	private List<NumericDimConfig> numericDimensions;
	
	public List<NumericDimConfig> getNumericDimensions() {
		return numericDimensions;
	}
	@XmlElement(name="NumericDimConfig")
	public void setNumericDimensions(List<NumericDimConfig> numericDimensions) {
		this.numericDimensions = numericDimensions;
	}
}
