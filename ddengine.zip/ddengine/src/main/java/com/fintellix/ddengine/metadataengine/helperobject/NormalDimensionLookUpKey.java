package com.fintellix.ddengine.metadataengine.helperobject;

public class NormalDimensionLookUpKey {

	private String objectName;
	private String idColumn;
	private String bkeyColumn;
	private String dataSourceInd;
	private String hierarchicalIndicator;
	
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public String getIdColumn() {
		return idColumn;
	}
	public void setIdColumn(String idColumn) {
		this.idColumn = idColumn;
	}
	public String getBkeyColumn() {
		return bkeyColumn;
	}
	public void setBkeyColumn(String bkeyColumn) {
		this.bkeyColumn = bkeyColumn;
	}
	public String getHierarchicalIndicator() {
		return hierarchicalIndicator;
	}
	public void setHierarchicalIndicator(String hierarchicalIndicator) {
		this.hierarchicalIndicator = hierarchicalIndicator;
	}
	
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof NormalDimensionLookUpKey)) return false;
		NormalDimensionLookUpKey key = (NormalDimensionLookUpKey) o;
		return objectName.equals(key.objectName) && idColumn.equals(key.idColumn) && bkeyColumn.equals(key.bkeyColumn) && dataSourceInd.equals(key.dataSourceInd) && hierarchicalIndicator.equals(key.hierarchicalIndicator) ;
	}

	@Override
	public int hashCode() {
		  int result = 17;
	        result = 31 * result + objectName.hashCode();
	        result = 31 * result + idColumn.hashCode();
	        result = 31 * result + bkeyColumn.hashCode();
	        result = 31 * result + dataSourceInd.hashCode();
	        result = 31 * result + hierarchicalIndicator.hashCode();
	        return result;
	}
	public String getDataSourceInd() {
		return dataSourceInd;
	}
	public void setDataSourceInd(String dataSourceInd) {
		this.dataSourceInd = dataSourceInd;
	}
}
