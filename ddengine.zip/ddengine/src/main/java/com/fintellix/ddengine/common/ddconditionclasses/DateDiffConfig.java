package com.fintellix.ddengine.common.ddconditionclasses;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import org.hamcrest.core.IsEqual;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.common.CommonDDFunctions;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;


public class DateDiffConfig extends DDSubConditionConfig{

	private static Logger logger = LoggerFactory.getLogger(DateDiffConfig.class);
	
	private String dateDiffMethod;
	private String startDateDimensionName;
	private String endDateDimensionName;
	private String startDateFunction;
	private String endDateFunction;
	private String dimensionValue;
	private String dimensionValueLower;
	private String dimensionValueUpper;
	
	private Double dimensionValueLowerDouble;
	private Double dimensionValueUpperDouble;
	private Double dimensionValueDouble;
	
	public String getDateDiffMethod() {
		return dateDiffMethod;
	}
	@XmlElement(name="DateDiffMethod")
	public void setDateDiffMethod(String dateDiffMethod) {
		this.dateDiffMethod = dateDiffMethod;
	}
	public String getStartDateDimensionName() {
		return startDateDimensionName;
	}
	@XmlElement(name="StartDateDimensionName")
	public void setStartDateDimensionName(String startDateDimensionName) {
		this.startDateDimensionName = startDateDimensionName;
	}
	public String getEndDateDimensionName() {
		return endDateDimensionName;
	}
	@XmlElement(name="EndDateDimensionName")
	public void setEndDateDimensionName(String endDateDimensionName) {
		this.endDateDimensionName = endDateDimensionName;
	}
	public String getStartDateFunction() {
		return startDateFunction;
	}
	@XmlElement(name="StartDateFunction")
	public void setStartDateFunction(String startDateFunction) {
		this.startDateFunction = startDateFunction;
	}
	public String getEndDateFunction() {
		return endDateFunction;
	}
	@XmlElement(name="EndDateFunction")
	public void setEndDateFunction(String endDateFunction) {
		this.endDateFunction = endDateFunction;
	}
	
	public String getDimensionValue() {
		return dimensionValue;
	}
	@XmlElement(name="DimensionValue")
	public void setDimensionValue(String dimensionValue) {
		this.dimensionValue = dimensionValue;
	}
	public String getDimensionValueLower() {
		return dimensionValueLower;
	}
	@XmlElement(name="DimensionValueLower")
	public void setDimensionValueLower(String dimensionValueLower) {
		this.dimensionValueLower = dimensionValueLower;
	}
	public String getDimensionValueUpper() {
		return dimensionValueUpper;
	}
	@XmlElement(name="DimensionValueUpper")
	public void setDimensionValueUpper(String dimensionValueUpper) {
		this.dimensionValueUpper = dimensionValueUpper;
	}
	@Override
	public Boolean evaluateSubCondition(Integer periodId, 
			String bkeyToIDConvReqd, 
			Map<String, DDRecordDataObject> eachRecordData, 
			List<Integer> holidayPeriodIdList){
		//logger.info("EXEFLOW - DateDiffConfig -> evaluateSubCondition()");
		DateTime startDate = null;
		DateTime endDate = null;
		double dateDifference = 0.0;
		
		if(eachRecordData.get(getStartDateDimensionName().toUpperCase()).getIsNull() || eachRecordData.get(getEndDateDimensionName().toUpperCase()).getIsNull())
			return DDConstants.DD_FAILURE;
		
		startDate = CommonDDFunctions.applyDateFunction(getStartDateFunction(), new DateTime(eachRecordData.get(getStartDateDimensionName().toUpperCase()).getRecordFieldValue())); 
		endDate = CommonDDFunctions.applyDateFunction(getEndDateFunction(), new DateTime(eachRecordData.get(getEndDateDimensionName().toUpperCase()).getRecordFieldValue()));
	
		switch(CommonDDFunctions.toUpper(getDateDiffMethod()))	{
		case DDConstants.DATEDIFFMETHOD_DAILY:
			dateDifference = Days.daysBetween(startDate, endDate).getDays();
			break;

		case DDConstants.DATEDIFFMETHOD_WEEKLY:
			dateDifference = Days.daysBetween(startDate,endDate).getDays();
			dateDifference = dateDifference / 7;
			break;

		case DDConstants.DATEDIFFMETHOD_MONTHLY:
			dateDifference = CommonDDFunctions.getDifferenceInMonths(startDate,endDate);
			break;

		case DDConstants.DATEDIFFMETHOD_QUARTERLY:
			dateDifference = CommonDDFunctions.getDifferenceInMonths(startDate,endDate);
			dateDifference = dateDifference / 3.0;
			break;

		case DDConstants.DATEDIFFMETHOD_YEARLY:
			dateDifference = CommonDDFunctions.getDifferenceInMonths(startDate,endDate);
			dateDifference = dateDifference / 12.0;
			break;

		case DDConstants.DATEDIFFMETHOD_WORKINGDAYS:
			/*Jaya - Check whether start date is included or end date is included while computing days between	*/
			/*Jaya - check whether start date holiday or end date holiday has to be considered	accordingly*/
			dateDifference = CommonDDFunctions.getDifferenceInWorkingDays(startDate,endDate,holidayPeriodIdList);
			break;

		case DDConstants.DATEDIFFMETHOD_WHOLEMONTHS:
			dateDifference = CommonDDFunctions.getDifferenceInWholeMonths(startDate,endDate);
			break;

		// Should never come to default, so handling is to make sure we dont send back a null structure.
		default:
			return DDConstants.DD_FAILURE;			
	}

	return CommonDDFunctions.checkNumericCondition(getOperator(),dateDifference,getDimensionValueDouble(),getDimensionValueLowerDouble(),getDimensionValueUpperDouble());
}
	@Override
	public void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(
			List<String> underlyingColumns,
			List<DDMetadataObjectColumn> listOfMetadataObjectColumn,
			String sourceName) {

		List<DDMetadataObjectColumn> listOfMetadataObjectColumnFiltered = new ArrayList<DDMetadataObjectColumn>();

		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getStartDateDimensionName().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setStartDateDimensionName(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getEndDateDimensionName().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setEndDateDimensionName(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		underlyingColumns.add(this.getEndDateDimensionName());
		underlyingColumns.add(this.getStartDateDimensionName());
		
		this.setDimensionValueDouble(dimensionValue.length()>0?Double.parseDouble(dimensionValue):null);
		this.setDimensionValueLowerDouble(dimensionValueLower.length()>0?Double.parseDouble(dimensionValueLower):null);
		this.setDimensionValueUpperDouble(dimensionValueUpper.length()>0?Double.parseDouble(dimensionValueUpper):null);

	}
	public Double getDimensionValueLowerDouble() {
		return dimensionValueLowerDouble;
	}
	public void setDimensionValueLowerDouble(Double dimensionValueLowerDouble) {
		this.dimensionValueLowerDouble = dimensionValueLowerDouble;
	}
	public Double getDimensionValueUpperDouble() {
		return dimensionValueUpperDouble;
	}
	public void setDimensionValueUpperDouble(Double dimensionValueUpperDouble) {
		this.dimensionValueUpperDouble = dimensionValueUpperDouble;
	}
	public Double getDimensionValueDouble() {
		return dimensionValueDouble;
	}
	public void setDimensionValueDouble(Double dimensionValueDouble) {
		this.dimensionValueDouble = dimensionValueDouble;
	}
	public String toString()	{
		String subCondition = "Sub-condition: Difference between ";
		subCondition += getStartDateFunction() + "("+ getStartDateDimensionName()+") and ";
		subCondition += getEndDateFunction() + " ("+ getEndDateDimensionName()+") ";
		subCondition += getDateDiffMethod();
		subCondition += " "+getOperator();
		if(getOperator().equals(DDConstants.DDOPER_BETWEEN) || getOperator().equals(DDConstants.DDOPER_BETWEEN_LOWER_EXCLUSIVE) || getOperator().equals(DDConstants.DDOPER_BETWEEN_UPPER_EXCLUSIVE))
			subCondition += " "+getDimensionValueLower() +" and "+getDimensionValueUpper();
		else
			subCondition += " "+getDimensionValue();
		
		return subCondition;
	}
	
}
