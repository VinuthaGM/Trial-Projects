package com.fintellix.ddengine.automationtest.writer;

import java.sql.Statement;
import java.util.Map;
import java.util.Set;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;

public class AutomationTargetWriter {
	StringBuffer columns=new StringBuffer();
	StringBuffer values=new StringBuffer();
	public Boolean insertIntoTargetTable(String tableName,Map<String, DDRecordDataObject> columnNameAndMetadataMap,Statement st1){
		System.out.println("AutomationTest->AutomationTargetWriter->insertIntoTargetTable()");
		Set<String> columnNames=columnNameAndMetadataMap.keySet();
		try {	
			columns.replace(0, columns.length(), "");
			values.replace(0, values.length(), "");
			for(String singleCol:columnNames){
					columns.append(singleCol.trim()+",");
					values.append("'"+(columnNameAndMetadataMap.get(singleCol).getIsNull()==true?"":columnNameAndMetadataMap.get(singleCol).getRecordFieldValue().toString().trim())+"',");                   
						}
			if(columns.length()!=0)					
				st1.executeUpdate("insert into "+tableName+" ("+columns.substring(0, columns.length()-1)+") values("+values.substring(0,values.length()-1)+")");
			else
				return false;

			return true;
		} catch (Exception e) {
			System.err.println("FAILED TO WRITE TO TARGET");
			e.printStackTrace();
			return false;
		}
	}
}
