package com.fintellix.ddengine.metadataengine.model;


public class DDMetadataObjectColumn {

	private DDMetadataObjectColumnPk ddMetadataObjectColumnPk;
	private String isReferential;
	private Integer columnPosition;
	private String columnDataType;
	private Integer columnDataLength;
	private Integer columnDataPrecision;
	private Integer columnDataScale;
	private String columnNullable;
	private String columnType;
	private String businessName;
	private String businessNameAltLang;
	private String isActive;
	private String referenceObjectName;
	private String hierarchicalIndicator;

	public static class DDMetadataObjectColumnPk {
		
		private String columnName;
		private String objectName;
		private Integer solutionId;

		public String getColumnName() {
			return columnName;
		}

		public void setColumnName(String columnName) {
			this.columnName = columnName;
		}

		public String getObjectName() {
			return objectName;
		}

		public void setObjectName(String objectName) {
			this.objectName = objectName;
		}

		public Integer getSolutionId() {
			return solutionId;
		}

		public void setSolutionId(Integer solutionId) {
			this.solutionId = solutionId;
		}
		
		
	}


	public DDMetadataObjectColumnPk getDdMetadataObjectColumnPk() {
		return ddMetadataObjectColumnPk;
	}
	public void setDdMetadataObjectColumnPk(
			DDMetadataObjectColumnPk ddMetadataObjectColumnPk) {
		this.ddMetadataObjectColumnPk = ddMetadataObjectColumnPk;
	}

	public String getIsReferential() {
		return isReferential;
	}

	public void setIsReferential(String isReferential) {
		this.isReferential = isReferential;
	}

	public Integer getColumnPosition() {
		return columnPosition;
	}
	public void setColumnPosition(Integer columnPosition) {
		this.columnPosition = columnPosition;
	}

	public String getColumnDataType() {
		return columnDataType;
	}

	public void setColumnDataType(String columnDataType) {
		this.columnDataType = columnDataType;
	}
	public Integer getColumnDataLength() {
		return columnDataLength;
	}

	public void setColumnDataLength(Integer columnDataLength) {
		this.columnDataLength = columnDataLength;
	}

	public Integer getColumnDataPrecision() {
		return columnDataPrecision;
	}

	public void setColumnDataPrecision(Integer columnDataPrecision) {
		this.columnDataPrecision = columnDataPrecision;
	}

	public Integer getColumnDataScale() {
		return columnDataScale;
	}
	public void setColumnDataScale(Integer columnDataScale) {
		this.columnDataScale = columnDataScale;
	}
	public String getColumnNullable() {
		return columnNullable;
	}
	public void setColumnNullable(String columnNullable) {
		this.columnNullable = columnNullable;
	}
	public String getColumnType() {
		return columnType;
	}
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}
	public String getBusinessName() {
		return businessName.toLowerCase();
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName.toLowerCase();
	}
	public String getBusinessNameAltLang() {
		return businessNameAltLang;
	}
	public void setBusinessNameAltLang(String businessNameAltLang) {
		this.businessNameAltLang = businessNameAltLang;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getReferenceObjectName() {
		return referenceObjectName;
	}
	public void setReferenceObjectName(String referenceObjectName) {
		this.referenceObjectName = referenceObjectName;
	}
	public String getHierarchicalIndicator() {
		return hierarchicalIndicator;
	}
	public void setHierarchicalIndicator(String hierarchicalIndicator) {
		this.hierarchicalIndicator = hierarchicalIndicator;
	}
}
