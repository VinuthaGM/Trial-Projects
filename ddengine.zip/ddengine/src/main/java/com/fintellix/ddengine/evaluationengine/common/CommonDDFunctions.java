package com.fintellix.ddengine.evaluationengine.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.IsoFields;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.ddconditionclasses.StringDimConfig;

public class CommonDDFunctions {
	
	private static Logger logger = LoggerFactory.getLogger(StringDimConfig.class);
	
	/* This function doesn't modify the input, it just returns the left and right trimmed value of input string */ 
	public static String trim(String str)	{ 
		//logger.info("EXEFLOW CommonDDFunctions -> trim");
		if(null == str) return str;
		
		return str.trim();

	}
	public static String toUpper(String str)	{
		//logger.info("EXEFLOW CommonDDFunctions -> toUpper");
		if(null == str) return str;
		
		return str.toUpperCase();
	}
	public static Boolean isIDEmpty(Integer i)	{
	//	logger.info("EXEFLOW CommonDDFunctions -> isIDEmpty");
		if(null == i) return DDConstants.DD_SUCCESS;
		
		return i.equals(DDConstants.DD_NULL_DATA);
	}
	public static Boolean isIDNotEmpty(Integer i)	{
		//logger.info("EXEFLOW CommonDDFunctions -> isIDNotEmpty");
		if(null == i) return DDConstants.DD_FAILURE;
		
		return !(i.equals(DDConstants.DD_NULL_DATA));
		
	}
	/* If string is null, can we say it as empty?	*/
	public static Boolean isStringEmpty(String str)	{
		//logger.info("EXEFLOW CommonDDFunctions -> isStringEmpty");
		if(null == str) return DDConstants.DD_SUCCESS;
		
		return str.isEmpty();
	}
	public static Boolean isStringNotEmpty(String str)	{
		//logger.info("EXEFLOW CommonDDFunctions -> isStringNotEmpty");
		if(null == str) return DDConstants.DD_FAILURE;
		
		return !(str.isEmpty());
	}
	public static Boolean stringContains(String inputStr, String searchPattern)	{
		//logger.info("EXEFLOW CommonDDFunctions -> stringContains");
		if(null == inputStr || null == searchPattern)
			return DDConstants.DD_FAILURE;
		
		return inputStr.contains(searchPattern);
		
	}
	public static Boolean stringDoesNotContain(String inputStr, String searchPattern)	{
	//	logger.info("EXEFLOW CommonDDFunctions -> stringDoesNotContain");
		if(null == inputStr || null == searchPattern)
			return DDConstants.DD_SUCCESS;
		
		return !(inputStr.contains(searchPattern));
		
	}
	/*public static Boolean isIdIN(Integer inStr, String searchPattern)	{
		System.out.println("Entered isIN with args: "+ inStr + " "+ searchPattern);
		if(null == inStr || null == searchPattern)
			return DDConstants.DD_FAILURE;
		
		for(String token: inStr.split(","))	{
			if(token.equals(searchPattern)) return DDConstants.DD_SUCCESS;
		}	
		return DDConstants.DD_FAILURE;
		
	}*/
	public static Boolean isIN(String inStr, String inList)	{
		//logger.info("EXEFLOW CommonDDFunctions -> isIN");
		
		if(null == inStr || null == inList)
			return DDConstants.DD_FAILURE;
		
		for(String token: inList.split(","))	{
			if(token != null && token.equals(inStr)) return DDConstants.DD_SUCCESS;
		}	
		return DDConstants.DD_FAILURE;
		
	}
	public static Boolean isNotIN(String inStr, String inList)	{
		//logger.info("EXEFLOW CommonDDFunctions -> isNotIN");
		if(null == inStr || null == inList)
			return DDConstants.DD_SUCCESS;
		
		for(String token: inList.split(","))	{
			if(token != null && token.equals(inStr)) return DDConstants.DD_FAILURE;
		}	
		return DDConstants.DD_SUCCESS;
		
	}
	public static Boolean stringBeginsWith(String inputStr, String searchPattern)	{
		//logger.info("EXEFLOW CommonDDFunctions -> stringBeginsWith");
		if(null == inputStr || null == searchPattern) return DDConstants.DD_FAILURE;
		
		return inputStr.startsWith(searchPattern);
	}
	public static Boolean stringEndsWith(String inputStr, String searchPattern)	{
		//logger.info("EXEFLOW CommonDDFunctions -> stringEndsWith");
		if(null == inputStr || null == searchPattern) return DDConstants.DD_FAILURE;
		
		return inputStr.endsWith(searchPattern);
	}
	public static Boolean stringEquals(String str1, String str2)	{
		//logger.info("EXEFLOW CommonDDFunctions -> stringEquals");
		if(null == str1 || null == str2) return DDConstants.DD_FAILURE;
		
		return str1.equals(str2);
	}
	public static Boolean stringNotEquals(String str1, String str2)	{
		//logger.info("EXEFLOW CommonDDFunctions -> stringNotEquals");
		if(null == str1 || null == str2) return DDConstants.DD_SUCCESS;
		
		return !(str1.equals(str2));
	}
	/*static Integer getDaysInMonth(Integer year, Integer month)	{
		logger.info("EXEFLOW CommonDDFunctions -> getDaysInMonth");
		if((month.compareTo(1) < 0) || (month.compareTo(12) > 0)) return 0;
		
		return YearMonth.of(year,  month).lengthOfMonth();
		
	}*/
	public static Boolean checkNumericCondition(String ddOperator, Double dataValue, Double conditionValue, Double columnValueLower, Double columnValueUpper)	{
		//logger.info("EXEFLOW CommonDDFunctions -> checkNumericCondition");
		Boolean returnValue = DDConstants.DD_FAILURE;
		
		if(null == dataValue)
			return DDConstants.DD_FAILURE;
		
		switch(ddOperator) { 
			case DDConstants.DDOPER_LESSTHAN:
				if(conditionValue == null) returnValue = DDConstants.DD_FAILURE; 
				else if(dataValue.compareTo(conditionValue) < 0) {
					returnValue = DDConstants.DD_SUCCESS;				
				}
				break;
			case DDConstants.DDOPER_GREATERTHAN :
				if(conditionValue == null) returnValue = DDConstants.DD_FAILURE; 
				else if(dataValue.compareTo(conditionValue) > 0) {
					returnValue = DDConstants.DD_SUCCESS;					
				}
				break;
			case DDConstants.DDOPER_LESSTHANOREQUALTO :
				if(conditionValue == null) returnValue = DDConstants.DD_FAILURE; 
				else if(dataValue.compareTo(conditionValue) <= 0) {
					returnValue = DDConstants.DD_SUCCESS;					
				}
				break;
			case DDConstants.DDOPER_GREATERTHANOREQUALTO :
				if(conditionValue == null) returnValue = DDConstants.DD_FAILURE; 
				else if(dataValue.compareTo(conditionValue) >= 0) {
					returnValue = DDConstants.DD_SUCCESS;					
				}
				break;
			case DDConstants.DDOPER_EQUALTO :
				if(conditionValue == null) returnValue = DDConstants.DD_FAILURE; 
				else returnValue = dataValue.equals(conditionValue);
					break;
				
			case DDConstants.DDOPER_NOTEQUALTO :
				if(conditionValue == null) returnValue = DDConstants.DD_FAILURE; 
				else returnValue = !(dataValue.equals(conditionValue));
					break;
			case DDConstants.DDOPER_BETWEEN :
				if(null == columnValueLower || null == columnValueUpper) 
					returnValue = DDConstants.DD_FAILURE;
				else
					returnValue = (dataValue.compareTo(columnValueLower) >= 0 && dataValue.compareTo(columnValueUpper) <= 0);
				break;
			case DDConstants.DDOPER_BETWEEN_LOWER_EXCLUSIVE :
				if(null == columnValueLower || null == columnValueUpper) 
					returnValue = DDConstants.DD_FAILURE;
				else
					returnValue = (dataValue.compareTo(columnValueLower) > 0 && dataValue.compareTo(columnValueUpper) <= 0);
				break;
			case DDConstants.DDOPER_BETWEEN_UPPER_EXCLUSIVE :
				if(null == columnValueLower || null == columnValueUpper) 
					returnValue = DDConstants.DD_FAILURE;
				else
					returnValue = (dataValue.compareTo(columnValueLower) >= 0 && dataValue.compareTo(columnValueUpper) < 0);
				break;
			case DDConstants.DDOPER_UNSUPPORTEDOPER :
			default : 
					returnValue = DDConstants.DD_FAILURE;	
		
		}
		
		return returnValue;
		
	}
	public static Boolean checkRatioCondition(String operator, Double numerator, Double denominator, Double conditionValue, Double conditionValueLower, Double conditionValueUpper) {
		//logger.info("EXEFLOW CommonDDFunctions -> checkRatioCondition");
		Double ratioValue = 0.0;
		
		if(null == numerator || null == denominator) return DDConstants.DD_FAILURE;
	
		/*if( 0 == numerator) ratioValue = 0.0;
		else if (0 == denominator) ratioValue = 999999999999999.99;
		else ratioValue = numerator / denominator ;	*/
	
		ratioValue = (
				(numerator.equals(0.0))
					?0.0
					:(denominator.equals(0.0)
									?999999999999999.99
									:numerator/denominator));

		return checkNumericCondition(operator, ratioValue, conditionValue, conditionValueLower, conditionValueUpper);
		
	}
	/* Jaya - Check null handling in all date functions	*/
	public static DateTime convertDateToAbsoluteDate(Integer periodId, String timeBasis, Integer offset)
	{
		//logger.info("EXEFLOW CommonDDFunctions -> convertDateToAbsoluteDate");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		DateTime absDate = null;
		try {
			absDate = new DateTime(formatter.parse(periodId.toString()));
		} catch (ParseException e) {
			logger.info("ERROR IN CONVERTING TO ABSOLUTE DATE");
			return null; 
		}
		if(offset < -1) offset *= -1;
		switch(timeBasis)
		{
		case "D" :
			absDate = absDate.minusDays(offset);
			break;
		case "W" :
			absDate = absDate.minusDays(offset*7);
			break;
		
		case "M" :
			absDate = subtractMonthsYearsToDateWithMonthEndCheck(absDate, offset, 0);
			break;
		case "Q" :
			absDate = subtractMonthsYearsToDateWithMonthEndCheck(absDate, offset*3, 0);
			break;
		
		case "Y" :
			absDate = subtractMonthsYearsToDateWithMonthEndCheck(absDate, 0,offset);
			break;
		
		}
		return absDate;
	}
	/**************************************************************************************************************************************************
	 *   Name	:	subtractMonthsYearsToDateWithMonthEndCheck
	 *   Description: 	The function subtracts given number of months and years from inputDate. Send months and years as positive values.
	 *   		        Years is directly subtracted and months is subtracted after doing modules 12. If months is > 12, then it is divided by 12
	 *   		        and that many years is subtracted. In terms of days handling, if the input date has a day which is the last day of the 
	 *   		        month, then the output date is also set to last date of month. This is consistant with Oracle ADD_MONTHS
	 *   Input	: 	inputDate, years and months
	 *   Output	:  	result Date
	 *   Remarks    : 	Ex1:  Subtracting 2 months from 31-05-2015 will return 31-03-2015
	 *               	Ex2:  Subtracting 1 months from 25-06-2015 will return 25-05-2015
	 *               	Ex3:  Subtracting 1 months from 29-03-2015 will return 28-02-2015
	 *               	Ex4:  Subtracting 2 months from 28-02-2015 will return 31-12-2014
	 *               	Ex5:  Subtracting 1 year and 2 months from 28-06-2015 will return 28-04-2014
	 **************************************************************************************************************************************************/
	public static DateTime subtractMonthsYearsToDateWithMonthEndCheck(DateTime referenceDate, int months, int years)
	{
		//logger.info("EXEFLOW CommonDDFunctions -> subtractMonthsYearsToDateWithMonthEndCheck");
		Boolean		isLastDayInMonth = DDConstants.DD_FAILURE;	
		int		daysInResultMonth;
		int		resultDay;
		int		resultMonth;
		int		resultYear;
		// there will be no error handling in common functions, years and months should always be positive, if a negative value is passed, we just multiply it with -1
		/* Jaya - check if months & years can be negative	*/
		
		
		if (referenceDate.getDayOfMonth() == YearMonth.of(referenceDate.getYear(),referenceDate.getMonthOfYear()).lengthOfMonth()) 
			isLastDayInMonth = DDConstants.DD_SUCCESS;

		resultYear = referenceDate.getYear()   - years - (months / 12);

		if (referenceDate.getMonthOfYear() <= (months % 12 )) {
			resultYear  -= 1;
			resultMonth = referenceDate.getMonthOfYear() + 12 - (months % 12);
		}else{
			resultMonth =  referenceDate.getMonthOfYear() - (months % 12 ) ;
		}
		
		daysInResultMonth = YearMonth.of(resultYear, resultMonth).lengthOfMonth();
				

		if (isLastDayInMonth == DDConstants.DD_SUCCESS)
			resultDay = daysInResultMonth; // Last day of month maps to last day of result month
		else
			resultDay = (referenceDate.getDayOfMonth() > daysInResultMonth) ?  daysInResultMonth : referenceDate.getDayOfMonth() ;
		
		
		return (new DateTime(resultYear, resultMonth, resultDay, 0, 0, 0));
	}
	/**************************************************************************************************************************************************
	 *   Name	:	getDifferenceInMonths
	 *   Description: 	The function returns difference between two dates in Months, if both are months
	 *   Input	: 	startDate, endDate
	 *   Output	:  	
	 **************************************************************************************************************************************************/
	public static Double getDifferenceInMonths(DateTime startDate, DateTime endDate)
	{
		//logger.info("EXEFLOW CommonDDFunctions -> getDifferenceInMonths");
		Boolean		isStartDateLastDayInMonth = DDConstants.DD_FAILURE;	
		Boolean		isEndDateLastDayInMonth   = DDConstants.DD_FAILURE;	
		Double		dateDifference	=	0.0;

		if (startDate.getDayOfMonth() == YearMonth.of(startDate.getYear(),startDate.getMonthOfYear()).lengthOfMonth()) 
			isStartDateLastDayInMonth = DDConstants.DD_SUCCESS;

		if (endDate.getDayOfMonth() == YearMonth.of(endDate.getYear(),endDate.getMonthOfYear()).lengthOfMonth()) 
			isEndDateLastDayInMonth = DDConstants.DD_SUCCESS;

		dateDifference = (double) (( ( endDate.getYear()  -  startDate.getYear() ) * 12) +  ( endDate.getMonthOfYear() - startDate.getMonthOfYear()));

		if ( (!isStartDateLastDayInMonth) || ( !isEndDateLastDayInMonth) ) { 
			dateDifference = (double) dateDifference +  (double)endDate.getDayOfMonth()/endDate.dayOfMonth().getMaximumValue() - (double)startDate.getDayOfMonth()/startDate.dayOfMonth().getMaximumValue() ;
		}

		return dateDifference;
	}
	/**************************************************************************************************************************************************
	 *   Name	:	getDifferenceInWholeMonths
	 *   Description: 	The function returns difference between two dates in Months based on custom logic defined below.
	 *			If day component of start date is greater than day component of end date , then the difference between the two dates in 
	 *			months is returned, else the difference in months is reduced by 1.
	 *			If end date is less than start date, then the number of months is reduced by one if the day component of end date is less 
	 *			than day component of start date. 
	 *
	 *   Input	: 	startDate, endDate
	 *   Output	:  	Difference in Months in Integers, no fractions are returned.
	 **************************************************************************************************************************************************/
	public static Integer getDifferenceInWholeMonths(DateTime startDate, DateTime endDate)
	{
		//logger.info("EXEFLOW CommonDDFunctions -> getDifferenceInWholeMonths");
		Integer		monthDifference	=	0;
		char		reduceOneMonth   =  'N'; 

		monthDifference =  (( ( endDate.getYear()  - startDate.getYear() ) * 12) +  ( endDate.getMonthOfYear() - startDate.getMonthOfYear()));

		if (endDate.isAfter(startDate) || endDate.isEqual(startDate)) {
			if (endDate.getDayOfMonth() <= startDate.getDayOfMonth()) 
				reduceOneMonth = 'Y';
		} else {
			if (endDate.getDayOfMonth() < startDate.getDayOfMonth()) 
				reduceOneMonth = 'Y';
		}
		
		if ( reduceOneMonth == 'Y') {
			monthDifference = monthDifference  - 1; 
		}

		return monthDifference;
	}
	public static DateTime applyDateFunction(String ddDateFunctionType, DateTime inputDate)
	{
		//logger.info("EXEFLOW CommonDDFunctions -> applyDateFunction");
		DateTime 	outputDate = inputDate;
		int 		month;
		switch(ddDateFunctionType)
		{
			case DDConstants.DATEFUNC_STARTOFMONTH: 
				outputDate = new DateTime(inputDate.getYear(), inputDate.getMonthOfYear(), 1, 0, 0, 0);
				break;

			case DDConstants.DATEFUNC_ENDOFMONTH:
				outputDate = new DateTime(inputDate.getYear(), inputDate.getMonthOfYear(), inputDate.dayOfMonth().getMaximumValue(), 0, 0, 0);
				break;
			
			case DDConstants.DATEFUNC_STARTOFQUARTER:
				outputDate = new DateTime(inputDate.getYear(), ((inputDate.getMonthOfYear()-1)/3)*3 + 1, 1, 0, 0, 0);
				break;

			case DDConstants.DATEFUNC_ENDOFQUARTER:
				
				month = inputDate.getMonthOfYear()%3 == 0 ? inputDate.getMonthOfYear() : ((1+inputDate.getMonthOfYear()/3)*3);
				outputDate = new DateTime(inputDate.getYear(), month, YearMonth.of(inputDate.getYear(), month).lengthOfMonth(), 0, 0, 0);
				break;

			case DDConstants.DATEFUNC_STARTOFYEAR:
				outputDate = new DateTime(inputDate.getYear(), 1, 1, 0, 0, 0);
				break;

			case DDConstants.DATEFUNC_ENDOFYEAR:
				outputDate = new DateTime(inputDate.getYear(), 12, 31, 0, 0, 0);
				break;

			case DDConstants.DDOPER_UNSUPPORTEDDATEFUNC:
				break;
		}
		
		return outputDate;
	}
	public static Integer getDifferenceInWorkingDays(DateTime startDate, DateTime endDate, List<Integer> holidayPeriodIdList)
	{
		//logger.info("EXEFLOW CommonDDFunctions -> getDifferenceInWorkingDays");
		Integer dayCnt = Days.daysBetween(startDate, endDate).getDays();
		Integer holidayCnt = 0;
		
		
		if(dayCnt.equals(0)) return 0;
		
		Integer fromPeriodId = startDate.getYear() * 10000 + startDate.getMonthOfYear()*100 + startDate.getDayOfMonth();
		Integer toPeriodId = endDate.getYear() * 10000 + endDate.getMonthOfYear()*100 + endDate.getDayOfMonth();
		
		for(Integer periodId: holidayPeriodIdList)	{
			if(periodId.compareTo(toPeriodId) >  0)
				break;
			
			if(periodId.compareTo(fromPeriodId) >= 0) 
				holidayCnt++;
			
		}
		return (dayCnt - holidayCnt);
	}
	
}
