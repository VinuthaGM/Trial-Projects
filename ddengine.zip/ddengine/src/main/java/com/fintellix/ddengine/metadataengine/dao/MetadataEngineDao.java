package com.fintellix.ddengine.metadataengine.dao;

import java.util.List;

import com.fintellix.ddengine.metadataengine.helperobject.NormalDimensionLookUpKey;
import com.fintellix.ddengine.metadataengine.helperobject.NormalDimensionObject;
import com.fintellix.ddengine.metadataengine.model.DDLookupMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;
import com.fintellix.ddengine.metadataengine.model.DDPreprocessRulesMetadata;

public interface MetadataEngineDao {
	public List<DDPreprocessRulesMetadata> getDDPreprocessRulesMetadata();
	public List<DDLookupMaster> getDDLookupMaster();
	public List<DDMetadataObjectColumn> getDDMetadataObjectColumn();
	public List<Integer> getHolidaysListFromDimPeriod();
	public List<NormalDimensionObject> getNormalDimensionLookUpObject(NormalDimensionLookUpKey dimensionKey);


}
