package com.fintellix.ddengine.common.helperobject;

public class DDRecordDataObject {
	
	private Boolean isNull;
	private String dataType;
	private Object recordFieldValue;
	
	public Boolean getIsNull() {
		return isNull;
	}
	public void setIsNull(Boolean isNull) {
		this.isNull = isNull;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public Object getRecordFieldValue() {
		return recordFieldValue;
	}
	public void setRecordFieldValue(Object recordFieldValue) {
		this.recordFieldValue = recordFieldValue;
	}
	
}
