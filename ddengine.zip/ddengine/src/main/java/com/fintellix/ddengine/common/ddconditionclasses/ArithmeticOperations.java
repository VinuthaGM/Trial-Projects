package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ArithmeticOperations")
public class ArithmeticOperations {

	private List<ArithmeticOperationConfig> arithmeticOperations;
	
	public List<ArithmeticOperationConfig> getArithmeticOperations() {
		return arithmeticOperations;
	}
	@XmlElement(name="Operation")
	public void setArithmeticOperations(List<ArithmeticOperationConfig> arithmeticOperations) {
		this.arithmeticOperations = arithmeticOperations;
	}
	
}
