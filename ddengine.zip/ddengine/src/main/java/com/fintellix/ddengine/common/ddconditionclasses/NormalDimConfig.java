package com.fintellix.ddengine.common.ddconditionclasses;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import org.hamcrest.core.IsEqual;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.common.CommonDDFunctions;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;


public class NormalDimConfig extends DDSubConditionConfig{
	
	private static Logger logger = LoggerFactory.getLogger(NormalDimConfig.class);
	
	private String dimensionName;
	
	private String dimensionValueString;
	
	private String columnValueIds;
	
	private String hierarchicalIndicator;
	
	private String unChangedColumnValuesList;
	
	public String getDimensionName() {
		return dimensionName;
	}
	@XmlElement(name="DimensionName")
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public String getDimensionValueString() {
		return dimensionValueString;
	}
	@XmlElement(name="DimensionValueString")
	public void setDimensionValueString(String dimensionValueString) {
		this.dimensionValueString = dimensionValueString;
	}
	public String getHierarchicalIndicator() {
		return hierarchicalIndicator;
	}
	@XmlElement(name="HierarchicalIndicator")
	public void setHierarchicalIndicator(String hierarchicalIndicator) {
		this.hierarchicalIndicator = hierarchicalIndicator;
	}
	public String getUnChangedColumnValuesList() {
		return unChangedColumnValuesList;
	}
	@XmlElement(name="UnChangedColumnValuesList")
	public void setUnChangedColumnValuesList(String unChangedColumnValuesList) {
		this.unChangedColumnValuesList = unChangedColumnValuesList;
	}
	@Override
	public Boolean evaluateSubCondition(Integer periodId, String bkeyToIDConvReqd, Map<String, DDRecordDataObject> eachRecordData, List<Integer> holidayPeriodIdList){
		//logger.info("EXEFLOW DateDimConfig -> evaluateSubCondition");
		Boolean returnValue = DDConstants.DD_FAILURE;
		String inList = null;
		if(bkeyToIDConvReqd.equals("Y") )	{
			/* For Invalid bkeys, we are putting the converted surrogate id as -999 in pre-processing, if any invalid bkey is there, fail the condition.*/
			if((getOperator().equals(DDConstants.DDOPER_IN) || getOperator().equals(DDConstants.DDOPER_NOTIN)) && CommonDDFunctions.isIN(getColumnValueIds(), DDConstants.DD_INVALID_CONDITION_BKEY ))
				return DDConstants.DD_FAILURE;
			
			inList = getColumnValueIds();
		}
		else	{
			inList = getDimensionValueString();
		}
			
		String  s = null;
		if(eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue() != null)
			s = eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue().toString();
		
		switch(getOperator())	{
			case DDConstants.DDOPER_IN: 		
				returnValue = CommonDDFunctions.isIN(s== null ? null:s.toString(), inList);
				break;
		
			case DDConstants.DDOPER_NOTIN: 
				returnValue = CommonDDFunctions.isNotIN(s== null ? null:s.toString(), inList);
				break;
			/* Jaya - Check how to find out whether given input record column value is id value or bkey value, how to find if its empty	*/
			case DDConstants.DDOPER_ISEMPTY:
				returnValue = eachRecordData.get(getDimensionName().toUpperCase()).getIsNull();
				break;
			/* Jaya - Check how to find out whether given input record column value is id value or bkey value, how to find if its empty	*/
			case DDConstants.DDOPER_ISNOTEMPTY:
				returnValue = !(eachRecordData.get(getDimensionName().toUpperCase()).getIsNull());
				break;
			
			case DDConstants.DDOPER_UNSUPPORTEDOPER:
			default:
				returnValue = DDConstants.DD_FAILURE;
		}	
		return returnValue;
	}
	@Override
	public void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(
			List<String> underlyingColumns,
			List<DDMetadataObjectColumn> listOfMetadataObjectColumn,
			String sourceName) {
		List<DDMetadataObjectColumn> listOfMetadataObjectColumnFiltered = new ArrayList<DDMetadataObjectColumn>();	
		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getDimensionName().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setDimensionName(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		underlyingColumns.add(this.getDimensionName());
	}
	public String getColumnValueIds() {
		return columnValueIds;
	}
	public void setColumnValueIds(String columnValueIds) {
		this.columnValueIds = columnValueIds;
	}
	public String toString()	{
		String subCondition = "Sub-condition : "+getDimensionName()+ " ";
		subCondition += getOperator() + " Bkeys: [" +getDimensionValueString();
		subCondition += "] Ids: [" +getColumnValueIds()+"]";
		subCondition += "Unchanged Column List: ["+getUnChangedColumnValuesList();
		subCondition += "]";
		return subCondition;
	}
	

}
