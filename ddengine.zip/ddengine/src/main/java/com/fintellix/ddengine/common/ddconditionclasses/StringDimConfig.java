package com.fintellix.ddengine.common.ddconditionclasses;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import org.hamcrest.core.IsEqual;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.common.CommonDDFunctions;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;


public class StringDimConfig extends DDSubConditionConfig{

	private static Logger logger = LoggerFactory.getLogger(StringDimConfig.class);
	
	private String dimensionName;
	private String dimensionValueString;
	
	public String getDimensionName() {
		return dimensionName;
	}
	@XmlElement(name="DimensionName")
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}
	public String getDimensionValueString() {
		return dimensionValueString;
	}
	@XmlElement(name="DimensionValueString")
	public void setDimensionValueString(String dimensionValueString) {
		this.dimensionValueString = dimensionValueString;
	}
	@Override
	public Boolean evaluateSubCondition(Integer periodId, String bkeyToIDConvReqd, Map<String, DDRecordDataObject> eachRecordData, List<Integer> holidayPeriodIdList){
		//logger.info("EXEFLOW StringDimConfig -> evaluateSubCondition");
		Boolean returnValue = DDConstants.DD_FAILURE;
		String upperCaseConditionValue = null;
		String upperCaseDataValue = null;
		
		if(!getOperator().equals(DDConstants.DDOPER_ISEMPTY) && !getOperator().equals(DDConstants.DDOPER_ISNOTEMPTY))	{
			if(!eachRecordData.get(getDimensionName().toUpperCase()).getIsNull() )
				upperCaseDataValue = CommonDDFunctions.trim(CommonDDFunctions.toUpper((String)eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue()));
			upperCaseConditionValue = CommonDDFunctions.trim(CommonDDFunctions.toUpper(getDimensionValueString()));
		}	
			
		switch(getOperator())	{
			case DDConstants.DDOPER_EQUALS: 
				returnValue = CommonDDFunctions.stringEquals(upperCaseDataValue, upperCaseConditionValue);
				break;			
			case DDConstants.DDOPER_CONTAINS: 
				returnValue = CommonDDFunctions.stringContains(upperCaseDataValue, upperCaseConditionValue);
				break;
			case DDConstants.DDOPER_BEGINSWITH: 
				returnValue = CommonDDFunctions.stringBeginsWith(upperCaseDataValue, upperCaseConditionValue);
				break;
			case DDConstants.DDOPER_ENDSWITH: 
				returnValue = CommonDDFunctions.stringEndsWith(upperCaseDataValue, upperCaseConditionValue);
				break;
			case DDConstants.DDOPER_DOESNOTCONTAIN: 
				returnValue = CommonDDFunctions.stringDoesNotContain(upperCaseDataValue, upperCaseConditionValue);
				break;
			case DDConstants.DDOPER_ISEMPTY:
				returnValue = eachRecordData.get(getDimensionName().toUpperCase()).getIsNull();
				break;
			case DDConstants.DDOPER_ISNOTEMPTY:
				returnValue = !(eachRecordData.get(getDimensionName().toUpperCase()).getIsNull());
				break;
			
			case DDConstants.DDOPER_UNSUPPORTEDOPER:
			default:
				returnValue = DDConstants.DD_FAILURE;
		}	
		return returnValue;
	}
	@Override
	public void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(
			List<String> underlyingColumns,
			List<DDMetadataObjectColumn> listOfMetadataObjectColumn,
			String sourceName) {
		List<DDMetadataObjectColumn> listOfMetadataObjectColumnFiltered = new ArrayList<DDMetadataObjectColumn>();
		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getDimensionName().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setDimensionName(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		underlyingColumns.add(this.getDimensionName());

	}
	public String toString()	{
		String subCondition = "Sub-condition : "+getDimensionName()+ " ";
		subCondition += getOperator() + " "+getDimensionValueString();
		
		return subCondition;
	}
	
}
