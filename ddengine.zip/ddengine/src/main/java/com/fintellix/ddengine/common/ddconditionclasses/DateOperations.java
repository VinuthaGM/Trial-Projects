package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="DateOperations")
public class DateOperations {

	private List<DateDiffConfig> dateOperations;
	
	public List<DateDiffConfig> getDateOperations() {
		return dateOperations;
	}
	@XmlElement(name="DateDiffConfig")
	public void setDateOperations(List<DateDiffConfig> dateOperations) {
		this.dateOperations = dateOperations;
	}
}
