package com.fintellix.ddengine.automationtest.main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import com.fintellix.ddengine.automationtest.connection.AutomationConnection;
import com.fintellix.ddengine.automationtest.transformation.DDCustomTransformation;
import com.fintellix.ddengine.automationtest.writer.AutomationTargetWriter;
import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.manager.DDEvaluation;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.manager.DDMetadataManager;
import com.fintellix.ddengine.metadataengine.manager.DDMetadataManagerImpl;

public class AutomationMain {
	//private static Logger logger = LoggerFactory.getLogger(AutomationMain.class); 

	private static AutomationConnection automationConnection;
	private static DDEvaluation ddEvaluation;
	private static DDMetadataManager ddMetadataManager;
	private static Connection con;

	@SuppressWarnings("unused")
	public static void main(String str[]) {
		String sourceName =null;
		String targetName =null;
		Integer periodId = null;
		Integer solutionId = null;
		String jdbcFilePath = null;
		try{
			String [] input=str[0].split(",");
			sourceName=input[0];
			if(input[0].trim().length()==0){
				System.out.println("Source name is null");
				System.exit(1);
			}
			targetName=input[1];
			if(input[1].trim().length()==0){
				System.out.println("Target name is Blank");
				System.exit(1);
			}
			if(input[2].trim().length()==0){
				System.out.println("Period id is Blank");
				System.exit(1);
			}
			else
				periodId=Integer.parseInt(input[2]);

			if(input[3].trim().length()==0){
				System.out.println("Solution id is Blank"); 
				System.exit(1);
			}
			else
				solutionId=Integer.parseInt(input[3]);

			jdbcFilePath=input[4];
			if(input[4].trim().length()==0){
				System.out.println("JDBC properties File path is Blank");
				System.exit(1);
			}
		}catch(Exception e){
			e.printStackTrace();
			System.err.println("ERROR WHILE FETCHING ARGUMENTS FROM COMMAND LINE");
			System.exit(1);
		}

		automationConnection=new AutomationConnection(jdbcFilePath); 
		ddMetadataManager=new DDMetadataManagerImpl();
		con=automationConnection.getMartDbConnection();	
		Map<String, DDRecordDataObject> columnNameAndMetadataMap;
		AutomationTargetWriter automationTargetWriter=new AutomationTargetWriter();

		try{	
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from "+sourceName+" where period_id="+periodId);
			DDMetadataMaster ddMetadataMasterObject=ddMetadataManager.getDDMetadataForSourceTarget(sourceName, targetName, con, automationConnection.getAppDbConnection(), periodId, solutionId);
			DDCustomTransformation ddCustomTransformation=new DDCustomTransformation(ddMetadataMasterObject);
			ddEvaluation=ddCustomTransformation.getDDEvaluationObject();
			List<String> dDimPorts=ddMetadataMasterObject.getApplicableDDimPorts();		
			Statement insertStatement=con.createStatement();
			if(ddMetadataMasterObject==null){
				System.err.println("THERE IS NO METADATA OBJECT TO COMPARE");
				System.exit(1);
			}
			else if(dDimPorts==null || dDimPorts.size()==0)
				System.err.println("THERE ARE NO DDIM PORTS TO COMPARE");

			if (!rs.next()) {
				System.err.println("THERE ARE NO RECORDS IN THE SOURCE TABLE->"+sourceName);
			} 
			else { 
				do {
					columnNameAndMetadataMap=ddCustomTransformation.handleCustomTransformationForEachRow(rs,dDimPorts);
					if(!ddEvaluation.handleDDEvaluationForEachInputRow(columnNameAndMetadataMap))  
						System.err.println("ERROR WHILE EVALUATING EACH INPUT ROW");

					if(!automationTargetWriter.insertIntoTargetTable(targetName,columnNameAndMetadataMap, insertStatement))
						System.err.println("INSERTION TO TARGET TABLE FAILED");
				} while (rs.next());
			}			

		}
		catch(Exception e){			
			e.printStackTrace();
		}
		finally{
			try {
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println("********END OF AUTOMATION TEST******* ");
		}	
	}
}
