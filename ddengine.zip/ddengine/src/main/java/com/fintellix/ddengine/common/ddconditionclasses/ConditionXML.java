package com.fintellix.ddengine.common.ddconditionclasses;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ConditionXML")
public class ConditionXML {

	private String derivedDimension;
    private String subjectArea;
    private Integer conditionId;
    private String derivedDimensionValue;
    private String conditionName;
    private String dataSourceName;
    private Integer dataSourceId;
    private Condition condition;
	public String getDerivedDimension() {
		return derivedDimension;
	}
	@XmlElement(name="DerivedDimension")
	public void setDerivedDimension(String derivedDimension) {
		this.derivedDimension = derivedDimension;
	}
	public String getSubjectArea() {
		return subjectArea;
	}
	@XmlElement(name="SubjectArea")
	public void setSubjectArea(String subjectArea) {
		this.subjectArea = subjectArea;
	}
	public Integer getConditionId() {
		return conditionId;
	}
	@XmlElement(name="ConditionID")
	public void setConditionId(Integer conditionId) {
		this.conditionId = conditionId;
	}
	public String getDerivedDimensionValue() {
		return derivedDimensionValue;
	}
	@XmlElement(name="DerivedDimensionValue")
	public void setDerivedDimensionValue(String derivedDimensionValue) {
		this.derivedDimensionValue = derivedDimensionValue;
	}
	public String getConditionName() {
		return conditionName;
	}
	@XmlElement(name="ConditionName")
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}
	public String getDataSourceName() {
		return dataSourceName;
	}
	@XmlElement(name="DataSourceName")
	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}
	public Integer getDataSourceId() {
		return dataSourceId;
	}
	@XmlElement(name="DataSourceID")
	public void setDataSourceId(Integer dataSourceId) {
		this.dataSourceId = dataSourceId;
	}
	public Condition getCondition() {
		return condition;
	}
	@XmlElement(name="Condition")
	public void setCondition(Condition condition) {
		this.condition = condition;
	}

    
    
}
