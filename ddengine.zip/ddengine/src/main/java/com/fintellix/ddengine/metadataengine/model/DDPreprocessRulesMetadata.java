package com.fintellix.ddengine.metadataengine.model;


public class DDPreprocessRulesMetadata {

	private DDPreprocessRulesMetadataPk ddPreprocessRulesMetadataPk;
	private Integer priorityRecordStartDate;
	private Integer priorityRecordEndDate;
	private String conditionXml;
	private Integer rulesRecordStartDate;
	private Integer rulesRecordEndDate;
	private String sourceName;
	private String targetName;
	private String subjectArea;
	private String evaluationMode;
	private String infaInstanceName;
	private Integer dimReferenceId;
	private Integer userReferenceId;
	private String ddimValuebkey;
	private String ddTechName;
	private String bkeyToIdInd;

	public static class DDPreprocessRulesMetadataPk{

		private Integer xrefId;
		private Integer ddimValueId;
		private Integer solutionId;
		private Integer priority;
		private Integer serialNumber;
		private Integer conditionId;

		public Integer getXrefId() {
			return xrefId;
		}
		public void setXrefId(Integer xrefId) {
			this.xrefId = xrefId;
		}
		public Integer getDdimValueId() {
			return ddimValueId;
		}

		public void setDdimValueId(Integer ddimValueId) {
			this.ddimValueId = ddimValueId;
		}
		public Integer getSolutionId() {
			return solutionId;
		}

		public void setSolutionId(Integer solutionId) {
			this.solutionId = solutionId;
		}
		public Integer getPriority() {
			return priority;
		}

		public void setPriority(Integer priority) {
			this.priority = priority;
		}
		public Integer getSerialNumber() {
			return serialNumber;
		}

		public void setSerialNumber(Integer serialNumber) {
			this.serialNumber = serialNumber;
		}
		public Integer getConditionId() {
			return conditionId;
		}

		public void setConditionId(Integer conditionId) {
			this.conditionId = conditionId;
		}

	}
	public DDPreprocessRulesMetadataPk getDdPreprocessRulesMetadataPk() {
		return ddPreprocessRulesMetadataPk;
	}
	public void setDdPreprocessRulesMetadataPk(
			DDPreprocessRulesMetadataPk ddPreprocessRulesMetadataPk) {
		this.ddPreprocessRulesMetadataPk = ddPreprocessRulesMetadataPk;
	}
	public Integer getPriorityRecordStartDate() {
		return priorityRecordStartDate;
	}
	public void setPriorityRecordStartDate(Integer priorityRecordStartDate) {
		this.priorityRecordStartDate = priorityRecordStartDate;
	}
	public Integer getPriorityRecordEndDate() {
		return priorityRecordEndDate;
	}
	public void setPriorityRecordEndDate(Integer priorityRecordEndDate) {
		this.priorityRecordEndDate = priorityRecordEndDate;
	}
	public String getConditionXml() {
		return conditionXml;
	}
	public void setConditionXml(String conditionXml) {
		this.conditionXml = conditionXml;
	}
	public Integer getRulesRecordStartDate() {
		return rulesRecordStartDate;
	}
	public void setRulesRecordStartDate(Integer rulesRecordStartDate) {
		this.rulesRecordStartDate = rulesRecordStartDate;
	}
	public Integer getRulesRecordEndDate() {
		return rulesRecordEndDate;
	}
	public void setRulesRecordEndDate(Integer rulesRecordEndDate) {
		this.rulesRecordEndDate = rulesRecordEndDate;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getTargetName() {
		return targetName;
	}
	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}
	public String getSubjectArea() {
		return subjectArea;
	}
	public void setSubjectArea(String subjectArea) {
		this.subjectArea = subjectArea;
	}
	public String getEvaluationMode() {
		return evaluationMode;
	}
	public void setEvaluationMode(String evaluationMode) {
		this.evaluationMode = evaluationMode;
	}
	public String getInfaInstanceName() {
		return infaInstanceName;
	}
	public void setInfaInstanceName(String infaInstanceName) {
		this.infaInstanceName = infaInstanceName;
	}
	public Integer getDimReferenceId() {
		return dimReferenceId;
	}
	public void setDimReferenceId(Integer dimReferenceId) {
		this.dimReferenceId = dimReferenceId;
	}
	public Integer getUserReferenceId() {
		return userReferenceId;
	}
	public void setUserReferenceId(Integer userReferenceId) {
		this.userReferenceId = userReferenceId;
	}
	public String getDdimValuebkey() {
		return ddimValuebkey;
	}
	public void setDdimValuebkey(String ddimValuebkey) {
		this.ddimValuebkey = ddimValuebkey;
	}
	public String getDdTechName() {
		return ddTechName;
	}
	public void setDdTechName(String ddTechName) {
		this.ddTechName = ddTechName;
	}
	public String getBkeyToIdInd() {
		return bkeyToIdInd;
	}
	public void setBkeyToIdInd(String bkeyToIdInd) {
		this.bkeyToIdInd = bkeyToIdInd;
	}
}
