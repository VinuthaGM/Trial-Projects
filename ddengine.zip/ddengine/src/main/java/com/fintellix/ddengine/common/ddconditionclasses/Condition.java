package com.fintellix.ddengine.common.ddconditionclasses;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Condition")
public class Condition {

	private DateOperations dateOperations;
	private NormalDimensions normalDimensions;
	private NumericDimensions numericDimensions;
	private ArithmeticOperations arithmeticOperations;
	private StringDimensions stringDimensions;
	private DateDimensions dateDimensions;
	
	public DateOperations getDateOperations() {
		return dateOperations;
	}
	@XmlElement(name="DateOperations")
	public void setDateOperations(DateOperations dateOperations) {
		this.dateOperations = dateOperations;
	}
	public NormalDimensions getNormalDimensions() {
		return normalDimensions;
	}
	@XmlElement(name="NormalDimensions")
	public void setNormalDimensions(NormalDimensions normalDimensions) {
		this.normalDimensions = normalDimensions;
	}
	public NumericDimensions getNumericDimensions() {
		return numericDimensions;
	}
	@XmlElement(name="NumericDimensions")
	public void setNumericDimensions(NumericDimensions numericDimensions) {
		this.numericDimensions = numericDimensions;
	}
	public ArithmeticOperations getArithmeticOperations() {
		return arithmeticOperations;
	}
	@XmlElement(name="ArithmeticOperations")
	public void setArithmeticOperations(ArithmeticOperations arithmeticOperations) {
		this.arithmeticOperations = arithmeticOperations;
	}
	public StringDimensions getStringDimensions() {
		return stringDimensions;
	}
	@XmlElement(name="StringDimensions")
	public void setStringDimensions(StringDimensions stringDimensions) {
		this.stringDimensions = stringDimensions;
	}
	public DateDimensions getDateDimensions() {
		return dateDimensions;
	}
	@XmlElement(name="DateDimensions")
	public void setDateDimensions(DateDimensions dateDimensions) {
		this.dateDimensions = dateDimensions;
	}

	
	
}
