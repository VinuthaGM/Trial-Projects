package com.fintellix.ddengine.common.ddconditionclasses;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import org.hamcrest.core.IsEqual;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.common.CommonDDFunctions;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;


public class NumericDimConfig extends DDSubConditionConfig{

	private static Logger logger = LoggerFactory.getLogger(NumericDimConfig.class);
	
	private String dimensionName;
	private String dimensionValueLower;
	private String dimensionValueUpper;
	private String dimensionValue;
	
	private Double dimensionValueLowerDouble;
	private Double dimensionValueUpperDouble;
	private Double dimensionValueDouble;
	
	public String getDimensionName() {
		return dimensionName;
	}
	@XmlElement(name="DimensionName")
	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}

	public String getDimensionValueLower() {
		return dimensionValueLower;
	}
	@XmlElement(name="DimensionValueLower")
	public void setDimensionValueLower(String dimensionValueLower) {
		this.dimensionValueLower = dimensionValueLower;
	}
	public String getDimensionValueUpper() {
		return dimensionValueUpper;
	}
	@XmlElement(name="DimensionValueUpper")
	public void setDimensionValueUpper(String dimensionValueUpper) {
		this.dimensionValueUpper = dimensionValueUpper;
	}
	public String getDimensionValue() {
		return dimensionValue;
	}
	@XmlElement(name="DimensionValue")
	public void setDimensionValue(String dimensionValue) {
		this.dimensionValue = dimensionValue;
	}
	@Override
	public Boolean evaluateSubCondition(Integer periodId, String bkeyToIDConvReqd, Map<String, DDRecordDataObject> eachRecordData, List<Integer> holidayPeriodIdList){
		//logger.info("EXEFLOW NumericDimConfig -> evaluateSubCondition");
		
		Double dataValue = null;
		if (eachRecordData.get(getDimensionName().toUpperCase()).getIsNull())
			return DDConstants.DD_FAILURE;
		
		if(eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue() != null)
			dataValue = Double.parseDouble(eachRecordData.get(getDimensionName().toUpperCase()).getRecordFieldValue().toString());
		
		return CommonDDFunctions.checkNumericCondition(getOperator(), dataValue, getDimensionValueDouble(), getDimensionValueLowerDouble(), getDimensionValueUpperDouble());
				
	}
	@Override
	public void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(
			List<String> underlyingColumns,
			List<DDMetadataObjectColumn> listOfMetadataObjectColumn,
			String sourceName) {
		List<DDMetadataObjectColumn> listOfMetadataObjectColumnFiltered = new ArrayList<DDMetadataObjectColumn>();
		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getDimensionName().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setDimensionName(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		underlyingColumns.add(this.getDimensionName());
		
		this.setDimensionValueDouble(dimensionValue.length()>0?Double.parseDouble(dimensionValue):null);
		this.setDimensionValueLowerDouble(dimensionValueLower.length()>0?Double.parseDouble(dimensionValueLower):null);
		this.setDimensionValueUpperDouble(dimensionValueUpper.length()>0?Double.parseDouble(dimensionValueUpper):null);
	}
	public Double getDimensionValueLowerDouble() {
		return dimensionValueLowerDouble;
	}
	public void setDimensionValueLowerDouble(Double dimensionValueLowerDouble) {
		this.dimensionValueLowerDouble = dimensionValueLowerDouble;
	}
	public Double getDimensionValueUpperDouble() {
		return dimensionValueUpperDouble;
	}
	public void setDimensionValueUpperDouble(Double dimensionValueUpperDouble) {
		this.dimensionValueUpperDouble = dimensionValueUpperDouble;
	}
	public Double getDimensionValueDouble() {
		return dimensionValueDouble;
	}
	public void setDimensionValueDouble(Double dimensionValueDouble) {
		this.dimensionValueDouble = dimensionValueDouble;
	}
	public String toString()	{
		String subCondition = "Sub-condition: ";
		switch(getOperator())	{
		case DDConstants.DDOPER_BETWEEN:
			subCondition += " Between " + getDimensionValueLower() + " and " + getDimensionValueUpper();
			break;
		default:
			subCondition += getOperator() + getDimensionValue();	
		}
		return subCondition;
	}
}
