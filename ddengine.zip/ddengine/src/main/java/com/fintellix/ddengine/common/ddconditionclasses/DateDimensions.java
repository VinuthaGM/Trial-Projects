package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="DateDimensions")
public class DateDimensions {

	private List<DateDimConfig> dateDimensions;

	public List<DateDimConfig> getDateDimensions() {
		return dateDimensions;
	}
	@XmlElement(name="DateDimConfig")
	public void setDateDimensions(List<DateDimConfig> dateDimensions) {
		this.dateDimensions = dateDimensions;
	}
	
	
}
