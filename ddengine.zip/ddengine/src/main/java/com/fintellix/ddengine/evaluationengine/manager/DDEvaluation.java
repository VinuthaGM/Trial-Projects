package com.fintellix.ddengine.evaluationengine.manager;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster.DDMainCondition;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster.DDMetadata;

import com.fintellix.ddengine.common.ddconditionclasses.DDSubConditionConfig;
import com.fintellix.ddengine.common.ddconditionclasses.DateDiffConfig;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.evaluationengine.common.DDLogger;

public class DDEvaluation {
	private static Logger logger = LoggerFactory.getLogger(DDEvaluation.class);
	private DDMetadataMaster ddMetadataMaster;
	private DDLogger ddLogger;

	public void setDDMetadataMaster(DDMetadataMaster ddMetadataMaster) {
		this.ddMetadataMaster = ddMetadataMaster;
	}

	public void setDDLogger(DDLogger ddLogger) {
		this.ddLogger = ddLogger;
	}

	public Boolean handleDDEvaluationForEachInputRow(
			Map<String, DDRecordDataObject> columnMap) {
		//System.out.println(columnMap);
		for (DDMetadata ddMetadata : ddMetadataMaster.getDdimWiseMetadata()) {
			
			handleDDSingleEvaluation(columnMap, ddMetadata);
			
		}
		return DDConstants.DD_SUCCESS;

	}

	private Boolean handleDDSingleEvaluation(Map<String, DDRecordDataObject> columnMap,
			DDMetadata ddMetadata) {

		Boolean evaluationStatus = DDConstants.DD_FAILURE;
		DDRecordDataObject recordObj = null;
		//System.out.println("DD being evaluated: " +ddMetadata.getDdimTechName());
		
		/* Loop for each DDim Value/Bkey */
		for (DDMetadataMaster.DDConditionMetadata ddConditionMetadata : ddMetadata.getDdimWiseConditionMetadataList()) {
			
			/* Loop for each condition */
			for (DDMainCondition ddMainCondition : ddConditionMetadata.getMainConditionList()) {
		
				/* Loop for each sub-condition */
				for (DDSubConditionConfig ddSubCondition : ddMainCondition.getSubConditionList()) {
					//System.out.print(ddSubCondition);
					evaluationStatus = ddSubCondition.evaluateSubCondition(
							ddMetadata.getPeriodId(),
							ddMetadata.getBkeyToIdInd(), columnMap,
							ddMetadataMaster.getHolidayPeriodIdList());
					//System.out.println(" Result: "+evaluationStatus);
					/*
					 * As sub-conditions must be evaluated to true for the
					 * condition to be true, break the sub-condition loop if any
					 * one sub-condition fails.
					 */
					if (DDConstants.DD_FAILURE == evaluationStatus)
						break;
				}

				if (DDConstants.DD_SUCCESS == evaluationStatus) {
					
					/*
					 * Update the derived value in columnMap with
					 * userReferenceId/dimReferenceId/ddimValue,if the
					 * evaluation is successful, as its required for evaluation
					 * of DD on DD.
					 */
															
					if (ddConditionMetadata.getUserReferenceId() != null
							&& ddConditionMetadata.getUserReferenceId() != 0)
						columnMap.get(ddMetadata.getDdimTechName().toUpperCase()).setRecordFieldValue(ddConditionMetadata.getUserReferenceId());
					
					else if (ddConditionMetadata.getDimReferenceId() != null
							&& ddConditionMetadata.getDimReferenceId() != 0)
						columnMap.get(ddMetadata.getDdimTechName().toUpperCase()).setRecordFieldValue(ddConditionMetadata.getDimReferenceId());
					
					else	
						columnMap.get(ddMetadata.getDdimTechName().toUpperCase()).setRecordFieldValue(ddConditionMetadata.getDdimValueID());
						
					columnMap.get(ddMetadata.getDdimTechName().toUpperCase()).setIsNull(false);
					// System.out.println("Condition evaluation of "+ddMetadata.getDdimTechName()+" is successful for the value "+columnMap.get(ddMetadata.getDdimTechName().toUpperCase()).getRecordFieldValue());
					// Add record in evaluationLog, with appropriate details
						

					return evaluationStatus;
				}
			}
		}
		return DDConstants.DD_SUCCESS;
	}
}
