package com.fintellix.ddengine.common.ddconditionclasses;

import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import org.hamcrest.core.IsEqual;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fintellix.ddengine.common.helperobject.DDRecordDataObject;
import com.fintellix.ddengine.evaluationengine.common.CommonDDFunctions;
import com.fintellix.ddengine.evaluationengine.common.DDConstants;
import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;
import com.fintellix.ddengine.metadataengine.model.DDMetadataObjectColumn;


public class ArithmeticOperationConfig extends DDSubConditionConfig{
	private static Logger logger = LoggerFactory.getLogger(ArithmeticOperationConfig.class);
	
	private String operationType;
	private String dimensionNameLower;
	private String dimensionNameUpper;
	private String dimensionValueLower;
	private String dimensionValueUpper;
	private String dimensionValue;
	private Double dimensionValueLowerDouble;
	private Double dimensionValueUpperDouble;
	private Double dimensionValueDouble;

	public String getOperationType() {
		return operationType;
	}
	@XmlElement(name="OperationType")
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	public String getDimensionNameLower() {
		return dimensionNameLower;
	}
	@XmlElement(name="DimensionNameLower")
	public void setDimensionNameLower(String dimensionNameLower) {
		this.dimensionNameLower = dimensionNameLower;
	}
	public String getDimensionNameUpper() {
		return dimensionNameUpper;
	}
	@XmlElement(name="DimensionNameUpper")
	public void setDimensionNameUpper(String dimensionNameUpper) {
		this.dimensionNameUpper = dimensionNameUpper;
	}
	public String getDimensionValueLower() {
		return dimensionValueLower;
	}
	@XmlElement(name="DimensionValueLower")
	public void setDimensionValueLower(String dimensionValueLower) {
		this.dimensionValueLower = dimensionValueLower;
	}
	public String getDimensionValueUpper() {
		return dimensionValueUpper;
	}
	@XmlElement(name="DimensionValueUpper")
	public void setDimensionValueUpper(String dimensionValueUpper) {
		this.dimensionValueUpper = dimensionValueUpper;
	}
	public String getDimensionValue() {
		return dimensionValue;
	}
	@XmlElement(name="DimensionValue")
	public void setDimensionValue(String dimensionValue) {
		this.dimensionValue = dimensionValue;
	}
	@Override
	public Boolean evaluateSubCondition(Integer periodId, String bkeyToIDConvReqd, Map<String, DDRecordDataObject> eachRecordData, List<Integer> holidayPeriodIdList){
		
		Boolean returnValue = DDConstants.DD_FAILURE;
		Double numerator = (eachRecordData.get(getDimensionNameLower().toUpperCase()).getIsNull())
							?null
							:Double.parseDouble(eachRecordData.get(getDimensionNameLower().toUpperCase()).getRecordFieldValue().toString());
		Double denominator = (eachRecordData.get(getDimensionNameUpper().toUpperCase()).getIsNull())
				?null
				:Double.parseDouble(eachRecordData.get(getDimensionNameUpper().toUpperCase()).getRecordFieldValue().toString());

		switch(getOperationType())	{
		case DDConstants.DDOPERATION_RATIOOF:
			returnValue = CommonDDFunctions.checkRatioCondition(getOperator(),
					numerator, 
					denominator, 
					getDimensionValueDouble(), 
					getDimensionValueLowerDouble(), 
					getDimensionValueUpperDouble());
			break;
		case DDConstants.DDOPER_UNSUPPORTEDOPER:
		default:
			returnValue = DDConstants.DD_FAILURE;
		}
		
		return returnValue;
	}

	@Override
	public void handleLookupOfBusinessNameToTechNameAddtoUnderlyingColumns(
			List<String> underlyingColumns,
			List<DDMetadataObjectColumn> listOfMetadataObjectColumn,
			String sourceName) {

		List<DDMetadataObjectColumn> listOfMetadataObjectColumnFiltered = new ArrayList<DDMetadataObjectColumn>();
		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getDimensionNameLower().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setDimensionNameLower(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");
		
		listOfMetadataObjectColumnFiltered=select(listOfMetadataObjectColumn,having(on(DDMetadataObjectColumn.class).getDdMetadataObjectColumnPk().getObjectName(),IsEqual.equalTo(sourceName)).and(having(on(DDMetadataObjectColumn.class).getBusinessName(),IsEqual.equalTo(this.getDimensionNameUpper().toLowerCase()))));
		if(listOfMetadataObjectColumnFiltered.size()>0)
			this.setDimensionNameUpper(listOfMetadataObjectColumnFiltered.get(0).getDdMetadataObjectColumnPk().getColumnName());
		else
			logger.info("No technical column name found for source name and column business name");

		underlyingColumns.add(this.getDimensionNameLower());
		underlyingColumns.add(this.getDimensionNameUpper());

		this.setDimensionValueDouble(dimensionValue.length()>0?Double.parseDouble(dimensionValue):null);
		this.setDimensionValueLowerDouble(dimensionValueLower.length()>0?Double.parseDouble(dimensionValueLower):null);
		this.setDimensionValueUpperDouble(dimensionValueUpper.length()>0?Double.parseDouble(dimensionValueUpper):null);
	}
	public Double getDimensionValueLowerDouble() {
		return dimensionValueLowerDouble;
	}
	public void setDimensionValueLowerDouble(Double dimensionValueLowerDouble) {
		this.dimensionValueLowerDouble = dimensionValueLowerDouble;
	}
	public Double getDimensionValueUpperDouble() {
		return dimensionValueUpperDouble;
	}
	public void setDimensionValueUpperDouble(Double dimensionValueUpperDouble) {
		this.dimensionValueUpperDouble = dimensionValueUpperDouble;
	}
	public Double getDimensionValueDouble() {
		return dimensionValueDouble;
	}
	public void setDimensionValueDouble(Double dimensionValueDouble) {
		this.dimensionValueDouble = dimensionValueDouble;
	}
	public String toString()	{
		String subCondition = "Sub-condition: "+getDimensionNameLower()+"/"+getDimensionNameUpper();
		switch(getOperator())	{
		case DDConstants.DDOPER_BETWEEN:
			subCondition += " Between " + getDimensionValueLower() + " and " + getDimensionValueUpper();
			break;
		default:
			subCondition += getOperator() + getDimensionValue();	
		}
		return subCondition;
	}
	
}

