package com.fintellix.ddengine.metadataengine.manager;

import java.sql.Connection;

import com.fintellix.ddengine.metadataengine.helperobject.DDMetadataMaster;

public interface DDMetadataManager {
	/**
	 * Returns the DDMetadataMaster for source target periodId soultionId combination
	 * @param sourceName
	 * @param targetName
	 * @param entityManagerMart
	 * @param entityManagerApp
	 * @param periodId
	 * @param solutionId
	 * @return DDMetadataMaster
	 */
	public DDMetadataMaster getDDMetadataForSourceTarget(String sourceName,String targetName,Connection connectionMart,Connection connectionApp,Integer periodId,Integer solutionId);
}
