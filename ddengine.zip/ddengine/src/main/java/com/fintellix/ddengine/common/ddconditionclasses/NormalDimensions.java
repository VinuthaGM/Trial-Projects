package com.fintellix.ddengine.common.ddconditionclasses;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="NormalDimensions")
public class NormalDimensions {

	private List<NormalDimConfig> normalDimensions;
	
	public List<NormalDimConfig> getNormalDimensions() {
		return normalDimensions;
	}
	@XmlElement(name="NormalDimConfig")
	public void setNormalDimensions(List<NormalDimConfig> normalDimensions) {
		this.normalDimensions = normalDimensions;
	}

}
