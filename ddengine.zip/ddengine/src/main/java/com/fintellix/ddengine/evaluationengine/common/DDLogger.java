package com.fintellix.ddengine.evaluationengine.common;

public class DDLogger {

}
